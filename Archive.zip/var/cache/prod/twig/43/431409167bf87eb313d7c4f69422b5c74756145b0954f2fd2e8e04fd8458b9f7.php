<?php

/* PortfolioPlatformBundle:Portfolio:index.html.twig */
class __TwigTemplate_f8a7f11fa3fa50ffc23ed71968b33f408426608ac99b79b6d2ef5736ccc1cc7d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "PortfolioPlatformBundle:Portfolio:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "
\t<div class = \"conteneurPorfolio\">
\t\t<h1 class = \"titrePortfolio\"> Portfolio </h1>

\t\t<div class = \"conteneurCategoriePortfolio\">
\t\t\t";
        // line 9
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) ? $context["categories"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["categorie"]) {
            // line 10
            echo "\t\t\t\t<form action = \"";
            echo $this->env->getExtension('routing')->getPath("portfolio_platform_affichageImageParCategorie");
            echo "\" method = \"post\"  class =\" categoriePortfolio\">
\t\t\t\t\t<input type = \"submit\" class = \"btn btn-default\" value = \"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute($context["categorie"], "valeur", array()), "html", null, true);
            echo "\" />
\t\t\t\t\t<input type = \"hidden\" value = \"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute($context["categorie"], "valeur", array()), "html", null, true);
            echo "\" name = \"lienCategoriePortfolio\" />
\t\t\t\t</form>
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['categorie'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 15
        echo "\t\t\t<button class = \"btn btn-primary boutonCategoriePortfolio\" onclick=\"self.location.href='";
        echo $this->env->getExtension('routing')->getPath("portfolio_platform_modification");
        echo "'\" > 
\t\t\t\tModifier
\t\t\t</button> \t\t\t
\t\t</div>

\t\t<div class = \"conteneurImagesEtUploadPortfolio\">
\t\t\t<div class = \"conteneurUploadPorfolio\">
\t\t\t\t<input type = \"file\" class = \"uploadPorfolio\" multiple=\"\" name=\"filesToUpload[]\" id=\"filesToUploadPortfolio\" />
\t\t\t\t<input  type = \"submit\" value = \"Upload\"  class = \"boutonUploadPortfolio\" />
\t\t        <input type=\"hidden\" value=\"";
        // line 24
        echo $this->env->getExtension('routing')->getPath("portfolio_platform_ajoutImageParCategorie");
        echo "\" id =  \"lienAjoutPhoto\" />
\t\t        <input type=\"hidden\" id=\"lienSuppressionPhotoporfolio\" value=\"";
        // line 25
        echo $this->env->getExtension('routing')->getPath("portfolio_platform_suppressionImageParCategorie");
        echo "\" />
\t        \t<input type = \"hidden\" value = \"";
        // line 26
        echo twig_escape_filter($this->env, (isset($context["categorieSingle"]) ? $context["categorieSingle"] : null), "html", null, true);
        echo "\" id = \"idCategoriePorfolio\" />
\t\t\t</div>

\t\t\t<div class = \"conteneurImagesPortfolio\">
\t\t\t\t";
        // line 30
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["images"]) ? $context["images"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
            echo " 
\t\t\t\t\t<div class = \"conteneurImagePortfolio\">
\t\t\t\t\t\t<img src = \"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($context["image"], "urlImage", array()), "html", null, true);
            echo "\" alt = \"Photo\" class = \"imagePortfolio\" />
\t\t\t\t\t\t<span   class=\"glyphicon glyphicon-remove fa-lg croixSuppressionPortfolio\" > </span>
\t\t\t\t\t</div>
\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 36
        echo "\t\t\t</div>
\t\t</div>


\t</div>

";
    }

    public function getTemplateName()
    {
        return "PortfolioPlatformBundle:Portfolio:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  105 => 36,  95 => 32,  88 => 30,  81 => 26,  77 => 25,  73 => 24,  60 => 15,  51 => 12,  47 => 11,  42 => 10,  38 => 9,  31 => 4,  28 => 3,  11 => 1,);
    }
}
/* {% extends "::base.html.twig" %}*/
/* */
/* {% block body %}*/
/* */
/* 	<div class = "conteneurPorfolio">*/
/* 		<h1 class = "titrePortfolio"> Portfolio </h1>*/
/* */
/* 		<div class = "conteneurCategoriePortfolio">*/
/* 			{% for categorie in categories %}*/
/* 				<form action = "{{path('portfolio_platform_affichageImageParCategorie')}}" method = "post"  class =" categoriePortfolio">*/
/* 					<input type = "submit" class = "btn btn-default" value = "{{categorie.valeur}}" />*/
/* 					<input type = "hidden" value = "{{categorie.valeur}}" name = "lienCategoriePortfolio" />*/
/* 				</form>*/
/* 			{% endfor %}*/
/* 			<button class = "btn btn-primary boutonCategoriePortfolio" onclick="self.location.href='{{path('portfolio_platform_modification')}}'" > */
/* 				Modifier*/
/* 			</button> 			*/
/* 		</div>*/
/* */
/* 		<div class = "conteneurImagesEtUploadPortfolio">*/
/* 			<div class = "conteneurUploadPorfolio">*/
/* 				<input type = "file" class = "uploadPorfolio" multiple="" name="filesToUpload[]" id="filesToUploadPortfolio" />*/
/* 				<input  type = "submit" value = "Upload"  class = "boutonUploadPortfolio" />*/
/* 		        <input type="hidden" value="{{ path('portfolio_platform_ajoutImageParCategorie') }}" id =  "lienAjoutPhoto" />*/
/* 		        <input type="hidden" id="lienSuppressionPhotoporfolio" value="{{ path('portfolio_platform_suppressionImageParCategorie') }}" />*/
/* 	        	<input type = "hidden" value = "{{categorieSingle}}" id = "idCategoriePorfolio" />*/
/* 			</div>*/
/* */
/* 			<div class = "conteneurImagesPortfolio">*/
/* 				{% for image in images %} */
/* 					<div class = "conteneurImagePortfolio">*/
/* 						<img src = "{{image.urlImage}}" alt = "Photo" class = "imagePortfolio" />*/
/* 						<span   class="glyphicon glyphicon-remove fa-lg croixSuppressionPortfolio" > </span>*/
/* 					</div>*/
/* 				{% endfor %}*/
/* 			</div>*/
/* 		</div>*/
/* */
/* */
/* 	</div>*/
/* */
/* {% endblock %}*/
/* */
