<?php

/* ::nav.html.twig */
class __TwigTemplate_3a1996a572e599ee83d125ba55b1799f615d0d241d90b626953a920e9bcb88c7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo " <nav class=\"navbar navbar-default\">
  <div class=\"container\"> <!-- fluid -> pour agrandir -->
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class=\"navbar-header\">
      <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#bs-example-navbar-collapse-1\" aria-expanded=\"false\">
        <span class=\"sr-only\">Toggle navigation</span>
        <span class=\"icon-bar\"></span>
        <span class=\"icon-bar\"></span>
        <span class=\"icon-bar\"></span>
      </button>
      <a class=\"navbar-brand\" href=\"#\">Administration</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
      <ul class=\"nav navbar-nav\">
        <li class=\"navFLP\"><a href=\"";
        // line 17
        echo $this->env->getExtension('routing')->getPath("accueil_platform_affichage_listePhoto");
        echo "\">Accueil <span class=\"sr-only\">(current)</span></a></li>
        <li class=\"navFLP\" ><a href=\"";
        // line 18
        echo $this->env->getExtension('routing')->getPath("presentation_platform_affichage");
        echo "\">Présentation</a></li>
        <li class=\"navFLP\"><a href=\"";
        // line 19
        echo $this->env->getExtension('routing')->getPath("contact_platform_affichage");
        echo "\">Contact</a></li>
        <li class=\"navFLP\"><a href=\"";
        // line 20
        echo $this->env->getExtension('routing')->getPath("portfolio_platform_affichage");
        echo "\">Portfolio</a></li>
        <li class=\"navFLP\"><a href=\"";
        // line 21
        echo $this->env->getExtension('routing')->getPath("tarif_platform_affichage");
        echo "\">Tarif</a></li>
        <li class=\"navFLP\"><a href=\"";
        // line 22
        echo $this->env->getExtension('routing')->getPath("evenement_platform_affichage");
        echo "\">Evénement</a></li>
        <li class=\"navFLP\"><a href=\"#\">Utilisateurs</a></li>

      <ul class=\"nav navbar-nav navbar-right\">
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>";
    }

    public function getTemplateName()
    {
        return "::nav.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 22,  53 => 21,  49 => 20,  45 => 19,  41 => 18,  37 => 17,  19 => 1,);
    }
}
/*  <nav class="navbar navbar-default">*/
/*   <div class="container"> <!-- fluid -> pour agrandir -->*/
/*     <!-- Brand and toggle get grouped for better mobile display -->*/
/*     <div class="navbar-header">*/
/*       <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">*/
/*         <span class="sr-only">Toggle navigation</span>*/
/*         <span class="icon-bar"></span>*/
/*         <span class="icon-bar"></span>*/
/*         <span class="icon-bar"></span>*/
/*       </button>*/
/*       <a class="navbar-brand" href="#">Administration</a>*/
/*     </div>*/
/* */
/*     <!-- Collect the nav links, forms, and other content for toggling -->*/
/*     <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">*/
/*       <ul class="nav navbar-nav">*/
/*         <li class="navFLP"><a href="{{ path('accueil_platform_affichage_listePhoto') }}">Accueil <span class="sr-only">(current)</span></a></li>*/
/*         <li class="navFLP" ><a href="{{ path('presentation_platform_affichage') }}">Présentation</a></li>*/
/*         <li class="navFLP"><a href="{{ path('contact_platform_affichage') }}">Contact</a></li>*/
/*         <li class="navFLP"><a href="{{ path('portfolio_platform_affichage') }}">Portfolio</a></li>*/
/*         <li class="navFLP"><a href="{{ path('tarif_platform_affichage') }}">Tarif</a></li>*/
/*         <li class="navFLP"><a href="{{ path('evenement_platform_affichage') }}">Evénement</a></li>*/
/*         <li class="navFLP"><a href="#">Utilisateurs</a></li>*/
/* */
/*       <ul class="nav navbar-nav navbar-right">*/
/*       </ul>*/
/*     </div><!-- /.navbar-collapse -->*/
/*   </div><!-- /.container-fluid -->*/
/* </nav>*/
