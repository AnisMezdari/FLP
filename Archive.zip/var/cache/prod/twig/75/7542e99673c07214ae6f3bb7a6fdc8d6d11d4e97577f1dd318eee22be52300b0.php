<?php

/* ::baseFront.html.twig */
class __TwigTemplate_ed96ff24aaecee7b6d9e0f182d2711cd77c5c66957f7fa7fba4a6975f738fb25 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'nav' => array($this, 'block_nav'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <meta name=\"viewport\" content=\"width-device-width, initial-scale-1.0\">

        <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

        <link rel=\"stylesheet\" href=\"path/to/font-awesome/css/font-awesome.min.css\" />
        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("web/bundles/framework/images/logo_symfony.png"), "html", null, true);
        echo "\" />
        <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css\" />
        <link href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css\" rel=\"stylesheet\">
        <link href=\"path/to/css/fileinput.min.css\" media=\"all\" rel=\"stylesheet\" type=\"text/css\" />
        <script src=\"//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js\"></script>
        <script type=\"text/javascript\" src=\"js/bootstrap-filestyle.min.js\"> </script>

        <link rel=\"stylesheet\" href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/Base/css/baseFront.css"), "html", null, true);
        echo "\" />
        <link rel=\"stylesheet\" href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/Accueil/css/accueilFront.css"), "html", null, true);
        echo "\" />

        ";
        // line 20
        $this->displayBlock('stylesheets', $context, $blocks);
        echo " 
    </head>
    <body>

    \t<script src=\"//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\"></script>
        <script src=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js\"></script> 
        ";
        // line 26
        $this->displayBlock('nav', $context, $blocks);
        // line 27
        echo "        ";
        $this->displayBlock('body', $context, $blocks);
        // line 28
        echo "
        ";
        // line 29
        $this->displayBlock('javascripts', $context, $blocks);
        // line 30
        echo "
        <footer class = \"frontFooter\">
             Copyright © 2017 Fleur de Lys Photography Tous droits Réservés.
        </footer>
    </body>

</html>";
    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        echo " Fleur de Lys Photographie | ";
    }

    // line 20
    public function block_stylesheets($context, array $blocks = array())
    {
    }

    // line 26
    public function block_nav($context, array $blocks = array())
    {
        echo " ";
        $this->loadTemplate("::navFront.html.twig", "::baseFront.html.twig", 26)->display($context);
        echo " ";
    }

    // line 27
    public function block_body($context, array $blocks = array())
    {
        echo "  ";
    }

    // line 29
    public function block_javascripts($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "::baseFront.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  111 => 29,  105 => 27,  97 => 26,  92 => 20,  86 => 7,  76 => 30,  74 => 29,  71 => 28,  68 => 27,  66 => 26,  57 => 20,  52 => 18,  48 => 17,  38 => 10,  32 => 7,  24 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <meta name="viewport" content="width-device-width, initial-scale-1.0">*/
/* */
/*         <title>{% block title %} Fleur de Lys Photographie | {% endblock %}</title>*/
/* */
/*         <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css" />*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('web/bundles/framework/images/logo_symfony.png') }}" />*/
/*         <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" />*/
/*         <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">*/
/*         <link href="path/to/css/fileinput.min.css" media="all" rel="stylesheet" type="text/css" />*/
/*         <script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>*/
/*         <script type="text/javascript" src="js/bootstrap-filestyle.min.js"> </script>*/
/* */
/*         <link rel="stylesheet" href="{{asset('bundles/Base/css/baseFront.css')}}" />*/
/*         <link rel="stylesheet" href="{{asset('bundles/Accueil/css/accueilFront.css')}}" />*/
/* */
/*         {% block stylesheets %}{% endblock %} */
/*     </head>*/
/*     <body>*/
/* */
/*     	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>*/
/*         <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script> */
/*         {% block nav %} {% include '::navFront.html.twig' %} {% endblock %}*/
/*         {% block body %}  {% endblock %}*/
/* */
/*         {% block javascripts %}{% endblock %}*/
/* */
/*         <footer class = "frontFooter">*/
/*              Copyright © 2017 Fleur de Lys Photography Tous droits Réservés.*/
/*         </footer>*/
/*     </body>*/
/* */
/* </html>*/
