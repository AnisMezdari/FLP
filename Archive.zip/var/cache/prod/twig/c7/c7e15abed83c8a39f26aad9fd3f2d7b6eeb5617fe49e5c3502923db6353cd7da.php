<?php

/* UserPlatformBundle:Default:index.html.twig */
class __TwigTemplate_172d073a70c420a1676ab06f6a619b522d4a3d40f06dfd13cd63e360c19e364c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "Hello World!
";
    }

    public function getTemplateName()
    {
        return "UserPlatformBundle:Default:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
/* Hello World!*/
/* */
