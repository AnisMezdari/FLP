<?php

/* EvenementPlatformBundle:Evenement:evenement.html.twig */
class __TwigTemplate_c95afb69478374c50b4435b3496409c7dba225d8e6a12334cc8fd3517d19b6d1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "Hello World!
";
    }

    public function getTemplateName()
    {
        return "EvenementPlatformBundle:Evenement:evenement.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
/* Hello World!*/
/* */
