<?php

/* ContactPlatformBundle:Contact:index.html.twig */
class __TwigTemplate_74c782b820f505c747cb0a032d7a9c306c70d3a2188660244eb276dd6630824f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "ContactPlatformBundle:Contact:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "
\t<form action = \"";
        // line 5
        echo $this->env->getExtension('routing')->getPath("contact_platform_modification");
        echo "\" method = \"post\" class = \"conteneurContact\" enctype=\"multipart/form-data\">
\t\t<h1 class = \"titreContact\"> Contact </h1>

\t\t<div class = \"conteneurbouton\">
\t\t\t<input type = \"submit\" name = \"boutonModifier\" value = \"Modifier\" />
\t\t</div>

\t\t<div class = \"conteneurContactImage\">
\t\t\t<img src = \"";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["contact"]) ? $context["contact"] : null), "urlImage", array()), "html", null, true);
        echo "\" alt = \"Image de l'entreprise\" class = \"imageContact\" />
\t\t\t<input type = \"file\" name = \"image\" class = \"boutonImageContact\" />
\t\t</div>

\t\t<div class = \"conteneurContactFormulaire\">
\t\t\t<div>
\t\t\t\t<input type = \"text\" name = \"titre\" value = \"";
        // line 19
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["contact"]) ? $context["contact"] : null), "titre", array()), "html", null, true);
        echo "\" class = \"form-control\"/>
\t\t\t</div>
\t\t\t<div>
\t\t\t\t<input type = \"text\" name = \"adresse\" value = \"";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["contact"]) ? $context["contact"] : null), "adresse", array()), "html", null, true);
        echo "\" class = \"form-control\" />
\t\t\t</div>
\t\t\t<div>
\t\t\t\t<input type = \"text\" name = \"email\" value = \"";
        // line 25
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["contact"]) ? $context["contact"] : null), "email", array()), "html", null, true);
        echo "\" class = \"form-control\" />
\t\t\t</div>
\t\t\t<div>
\t\t\t\t<input type = \"text\" name = \"tel\" value = \"";
        // line 28
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["contact"]) ? $context["contact"] : null), "telephone", array()), "html", null, true);
        echo "\" class = \"form-control\"/>
\t\t\t</div>
\t\t\t<div>
\t\t\t\t<input type = \"text\" name = \"telFixe\" value = \"";
        // line 31
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["contact"]) ? $context["contact"] : null), "telephoneFixe", array()), "html", null, true);
        echo "\" class = \"form-control\"/>
\t\t\t</div>
\t\t</div>
\t</form>

";
    }

    public function getTemplateName()
    {
        return "ContactPlatformBundle:Contact:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 31,  72 => 28,  66 => 25,  60 => 22,  54 => 19,  45 => 13,  34 => 5,  31 => 4,  28 => 3,  11 => 1,);
    }
}
/* {% extends "::base.html.twig" %}*/
/* */
/* {% block body %}*/
/* */
/* 	<form action = "{{path('contact_platform_modification')}}" method = "post" class = "conteneurContact" enctype="multipart/form-data">*/
/* 		<h1 class = "titreContact"> Contact </h1>*/
/* */
/* 		<div class = "conteneurbouton">*/
/* 			<input type = "submit" name = "boutonModifier" value = "Modifier" />*/
/* 		</div>*/
/* */
/* 		<div class = "conteneurContactImage">*/
/* 			<img src = "{{contact.urlImage}}" alt = "Image de l'entreprise" class = "imageContact" />*/
/* 			<input type = "file" name = "image" class = "boutonImageContact" />*/
/* 		</div>*/
/* */
/* 		<div class = "conteneurContactFormulaire">*/
/* 			<div>*/
/* 				<input type = "text" name = "titre" value = "{{contact.titre}}" class = "form-control"/>*/
/* 			</div>*/
/* 			<div>*/
/* 				<input type = "text" name = "adresse" value = "{{contact.adresse}}" class = "form-control" />*/
/* 			</div>*/
/* 			<div>*/
/* 				<input type = "text" name = "email" value = "{{contact.email}}" class = "form-control" />*/
/* 			</div>*/
/* 			<div>*/
/* 				<input type = "text" name = "tel" value = "{{contact.telephone}}" class = "form-control"/>*/
/* 			</div>*/
/* 			<div>*/
/* 				<input type = "text" name = "telFixe" value = "{{contact.telephoneFixe}}" class = "form-control"/>*/
/* 			</div>*/
/* 		</div>*/
/* 	</form>*/
/* */
/* {% endblock %}*/
