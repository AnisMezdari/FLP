<?php

/* ::base.html.twig */
class __TwigTemplate_f55e2ed428e765cb2e205dce66a664cae59b7efa5c178a80db135b292b8f34e3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'nav' => array($this, 'block_nav'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <meta name=\"viewport\" content=\"width-device-width, initial-scale-1.0\">

        <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

        <link rel=\"stylesheet\" href=\"path/to/font-awesome/css/font-awesome.min.css\" />
        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("web/bundles/framework/images/logo_symfony.png"), "html", null, true);
        echo "\" />
        <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css\" />

        <link rel=\"stylesheet\" href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/Accueil/css/accueil.css"), "html", null, true);
        echo "\" />
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/Presentation/css/presentationBO.css"), "html", null, true);
        echo "\" />
        <link rel=\"stylesheet\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/Contact/css/contactBO.css"), "html", null, true);
        echo "\" />
        <link rel=\"stylesheet\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/Portfolio/css/portfolioBo.css"), "html", null, true);
        echo "\" />
        <link rel=\"stylesheet\" href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/Portfolio/css/portfolioModifcationBO.css"), "html", null, true);
        echo "\" />
         <link rel=\"stylesheet\" href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/Tarif/css/tarif.css"), "html", null, true);
        echo "\" />

        <link href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css\" rel=\"stylesheet\">
        <link href=\"path/to/css/fileinput.min.css\" media=\"all\" rel=\"stylesheet\" type=\"text/css\" />
        <script src=\"//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js\"></script>
        <script type=\"text/javascript\" src=\"js/bootstrap-filestyle.min.js\"> </script> 
    

        ";
        // line 26
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 27
        echo "    </head>
    <body>
        <script src=\"//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\"></script>
        <script src=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js\"></script>        
        ";
        // line 31
        $this->displayBlock('nav', $context, $blocks);
        // line 32
        echo "
        ";
        // line 33
        $this->displayBlock('body', $context, $blocks);
        // line 34
        echo "
        ";
        // line 35
        $this->displayBlock('javascripts', $context, $blocks);
        // line 36
        echo "
        <script type=\"text/javascript\" src=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/Base/js/nav.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 38
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/Accueil/js/accueil.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 39
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/Portfolio/js/portfolioModification.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/Portfolio/js/portfolio.js"), "html", null, true);
        echo "\"></script>

        <footer class = \"footer\">
             Copyright © 2017 Fleur de Lys Photography Tous droits Réservés, site créé par Anis Mezdari & Maroin Kassas.
        </footer>
    </body>
</html>
";
    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        echo " Fleur de Lys Photographie | ";
    }

    // line 26
    public function block_stylesheets($context, array $blocks = array())
    {
    }

    // line 31
    public function block_nav($context, array $blocks = array())
    {
        echo " ";
        $this->loadTemplate("::nav.html.twig", "::base.html.twig", 31)->display($context);
        echo " ";
    }

    // line 33
    public function block_body($context, array $blocks = array())
    {
        echo "  ";
    }

    // line 35
    public function block_javascripts($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  147 => 35,  141 => 33,  133 => 31,  128 => 26,  122 => 7,  110 => 40,  106 => 39,  102 => 38,  98 => 37,  95 => 36,  93 => 35,  90 => 34,  88 => 33,  85 => 32,  83 => 31,  77 => 27,  75 => 26,  64 => 18,  60 => 17,  56 => 16,  52 => 15,  48 => 14,  44 => 13,  38 => 10,  32 => 7,  24 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <meta name="viewport" content="width-device-width, initial-scale-1.0">*/
/* */
/*         <title>{% block title %} Fleur de Lys Photographie | {% endblock %}</title>*/
/* */
/*         <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css" />*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('web/bundles/framework/images/logo_symfony.png') }}" />*/
/*         <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" />*/
/* */
/*         <link rel="stylesheet" href="{{asset('bundles/Accueil/css/accueil.css')}}" />*/
/*         <link rel="stylesheet" href="{{asset('bundles/Presentation/css/presentationBO.css')}}" />*/
/*         <link rel="stylesheet" href="{{asset('bundles/Contact/css/contactBO.css')}}" />*/
/*         <link rel="stylesheet" href="{{asset('bundles/Portfolio/css/portfolioBo.css')}}" />*/
/*         <link rel="stylesheet" href="{{asset('bundles/Portfolio/css/portfolioModifcationBO.css')}}" />*/
/*          <link rel="stylesheet" href="{{asset('bundles/Tarif/css/tarif.css')}}" />*/
/* */
/*         <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">*/
/*         <link href="path/to/css/fileinput.min.css" media="all" rel="stylesheet" type="text/css" />*/
/*         <script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>*/
/*         <script type="text/javascript" src="js/bootstrap-filestyle.min.js"> </script> */
/*     */
/* */
/*         {% block stylesheets %}{% endblock %}*/
/*     </head>*/
/*     <body>*/
/*         <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>*/
/*         <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>        */
/*         {% block nav %} {% include '::nav.html.twig' %} {% endblock %}*/
/* */
/*         {% block body %}  {% endblock %}*/
/* */
/*         {% block javascripts %}{% endblock %}*/
/* */
/*         <script type="text/javascript" src="{{asset('bundles/Base/js/nav.js')}}"></script>*/
/*         <script type="text/javascript" src="{{asset('bundles/Accueil/js/accueil.js')}}"></script>*/
/*         <script type="text/javascript" src="{{asset('bundles/Portfolio/js/portfolioModification.js')}}"></script>*/
/*         <script type="text/javascript" src="{{asset('bundles/Portfolio/js/portfolio.js')}}"></script>*/
/* */
/*         <footer class = "footer">*/
/*              Copyright © 2017 Fleur de Lys Photography Tous droits Réservés, site créé par Anis Mezdari & Maroin Kassas.*/
/*         </footer>*/
/*     </body>*/
/* </html>*/
/* */
