<?php

/* TarifPlatformBundle:Tarif:tarif.html.twig */
class __TwigTemplate_dba398a25fd99208b0dcf30837e2240afbaee031bffe46465299d91c753b1183 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "TarifPlatformBundle:Tarif:tarif.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "
\t<div   class = \"conteneurTarif\" >
\t\t<h1 class = \"titreTarif\"> Tarif </h1>

\t\t<form  action = \"";
        // line 8
        echo $this->env->getExtension('routing')->getPath("tarif_platform_ajout");
        echo "\" method = \"post\" class = \"conteneurTarif\" >
\t\t\t<input type = \"submit\" name = \"boutonAjoutTarif\" value = \"Ajouter\" />
\t\t</form>

\t\t<div class = \"conteneurBoutonTarif\" >
\t\t\t<div class = \"conteneurFormulairesTarif\">
\t\t\t\t";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["tarifs"]) ? $context["tarifs"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["tarif"]) {
            // line 15
            echo "\t\t\t\t\t<form action = \"";
            echo $this->env->getExtension('routing')->getPath("tarif_platform_modification");
            echo "\" method = \"post\" class = \"conteneurFormulaireTarif\" enctype=\"multipart/form-data\">
\t\t\t\t\t\t
\t\t\t\t\t\t<div class = \"conteneurImageTarif\">
\t\t\t\t\t\t\t<img src  = \"";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($context["tarif"], "urlImage", array()), "html", null, true);
            echo "\" alt = \"image\"  name = \"imageTarif\"  class = \"imageTarif\"/>
\t\t\t\t\t\t\t<input type = \"file\" name = \"inputFileTarif\"  />
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class = \"conteneurTextTarif\">
\t\t\t\t\t\t\t<input type = \"text\" value = \"";
            // line 22
            echo twig_escape_filter($this->env, $this->getAttribute($context["tarif"], "texte", array()), "html", null, true);
            echo "\" name = \"textTarif\"  class = \"form-control textTarif\" />
\t\t\t\t\t\t</div> 
\t\t\t\t\t\t<div class = \"conteneurPrixTarif\">
\t\t\t\t\t\t\t<input type = \"text\" value = \"";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute($context["tarif"], "prix", array()), "html", null, true);
            echo "\" name = \"prixTarif\" class = \"form-control prixTarif\" />
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<div class = \"conteneurBoutonModifTarif\">
\t\t\t\t\t\t\t<input type = \"submit\" name = \"boutonModifTarif\" value = \"Modifier\" class = \"boutonModifTarif\" />
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<input type = \"hidden\" value = \"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["tarif"], "id", array()), "html", null, true);
            echo "\" name = \"idTarif\" />
\t\t \t\t\t</form>
\t\t\t    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tarif'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 33
        echo "\t\t\t</div>
\t\t</div>
\t</div>

";
    }

    public function getTemplateName()
    {
        return "TarifPlatformBundle:Tarif:tarif.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  87 => 33,  78 => 30,  70 => 25,  64 => 22,  57 => 18,  50 => 15,  46 => 14,  37 => 8,  31 => 4,  28 => 3,  11 => 1,);
    }
}
/* {% extends "::base.html.twig" %}*/
/* */
/* {% block body %}*/
/* */
/* 	<div   class = "conteneurTarif" >*/
/* 		<h1 class = "titreTarif"> Tarif </h1>*/
/* */
/* 		<form  action = "{{ path('tarif_platform_ajout') }}" method = "post" class = "conteneurTarif" >*/
/* 			<input type = "submit" name = "boutonAjoutTarif" value = "Ajouter" />*/
/* 		</form>*/
/* */
/* 		<div class = "conteneurBoutonTarif" >*/
/* 			<div class = "conteneurFormulairesTarif">*/
/* 				{% for tarif in tarifs %}*/
/* 					<form action = "{{ path('tarif_platform_modification') }}" method = "post" class = "conteneurFormulaireTarif" enctype="multipart/form-data">*/
/* 						*/
/* 						<div class = "conteneurImageTarif">*/
/* 							<img src  = "{{tarif.urlImage}}" alt = "image"  name = "imageTarif"  class = "imageTarif"/>*/
/* 							<input type = "file" name = "inputFileTarif"  />*/
/* 						</div>*/
/* 						<div class = "conteneurTextTarif">*/
/* 							<input type = "text" value = "{{tarif.texte}}" name = "textTarif"  class = "form-control textTarif" />*/
/* 						</div> */
/* 						<div class = "conteneurPrixTarif">*/
/* 							<input type = "text" value = "{{tarif.prix}}" name = "prixTarif" class = "form-control prixTarif" />*/
/* 						</div>*/
/* 						<div class = "conteneurBoutonModifTarif">*/
/* 							<input type = "submit" name = "boutonModifTarif" value = "Modifier" class = "boutonModifTarif" />*/
/* 						</div>*/
/* 						<input type = "hidden" value = "{{tarif.id}}" name = "idTarif" />*/
/* 		 			</form>*/
/* 			    {% endfor %}*/
/* 			</div>*/
/* 		</div>*/
/* 	</div>*/
/* */
/* {% endblock %}*/
/* */
