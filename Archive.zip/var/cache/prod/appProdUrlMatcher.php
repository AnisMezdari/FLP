<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appProdUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        if (0 === strpos($pathinfo, '/administrateur')) {
            // evenement_platform_homepage
            if ($pathinfo === '/administrateur/evenement/affichage') {
                return array (  '_controller' => 'EvenementPlatformBundle:Evenemnt:affichage',  '_route' => 'evenement_platform_homepage',);
            }

            if (0 === strpos($pathinfo, '/administrateur/tarif')) {
                // tarif_platform_affichage
                if ($pathinfo === '/administrateur/tarif/affichage') {
                    return array (  '_controller' => 'Tarif\\PlatformBundle\\Controller\\TarifController::affichageAction',  '_route' => 'tarif_platform_affichage',);
                }

                // tarif_platform_modification
                if ($pathinfo === '/administrateur/tarif/modification') {
                    return array (  '_controller' => 'Tarif\\PlatformBundle\\Controller\\TarifController::modificationAction',  '_route' => 'tarif_platform_modification',);
                }

                // tarif_platform_ajout
                if ($pathinfo === '/administrateur/tarif/ajout') {
                    return array (  '_controller' => 'Tarif\\PlatformBundle\\Controller\\TarifController::ajoutAction',  '_route' => 'tarif_platform_ajout',);
                }

            }

            if (0 === strpos($pathinfo, '/administrateur/portfolio')) {
                // portfolio_platform_affichage
                if ($pathinfo === '/administrateur/portfolio/affichage') {
                    return array (  '_controller' => 'Portfolio\\PlatformBundle\\Controller\\PortfolioController::affichageAction',  '_route' => 'portfolio_platform_affichage',);
                }

                if (0 === strpos($pathinfo, '/administrateur/portfolio/modification')) {
                    // portfolio_platform_modification
                    if ($pathinfo === '/administrateur/portfolio/modification') {
                        return array (  '_controller' => 'Portfolio\\PlatformBundle\\Controller\\PortfolioController::modificationAction',  '_route' => 'portfolio_platform_modification',);
                    }

                    // portfolio_platform_modificationCategorie
                    if ($pathinfo === '/administrateur/portfolio/modification/categorie') {
                        return array (  '_controller' => 'Portfolio\\PlatformBundle\\Controller\\PortfolioController::modificationCategorieAction',  '_route' => 'portfolio_platform_modificationCategorie',);
                    }

                }

                if (0 === strpos($pathinfo, '/administrateur/portfolio/a')) {
                    // portfolio_platform_affichageImageParCategorie
                    if ($pathinfo === '/administrateur/portfolio/affichage/image') {
                        return array (  '_controller' => 'Portfolio\\PlatformBundle\\Controller\\PortfolioController::affichageParCategorieAction',  '_route' => 'portfolio_platform_affichageImageParCategorie',);
                    }

                    // portfolio_platform_ajoutImageParCategorie
                    if ($pathinfo === '/administrateur/portfolio/ajout/image') {
                        return array (  '_controller' => 'Portfolio\\PlatformBundle\\Controller\\PortfolioController::ajoutImageParCategorieAction',  '_route' => 'portfolio_platform_ajoutImageParCategorie',);
                    }

                }

                // portfolio_platform_suppressionImageParCategorie
                if ($pathinfo === '/administrateur/portfolio/suppression/image') {
                    return array (  '_controller' => 'Portfolio\\PlatformBundle\\Controller\\PortfolioController::modificationCategorieAction',  '_route' => 'portfolio_platform_suppressionImageParCategorie',);
                }

            }

            if (0 === strpos($pathinfo, '/administrateur/contact')) {
                // contact_platform_affichage
                if ($pathinfo === '/administrateur/contact/affichage') {
                    return array (  '_controller' => 'Contact\\PlatformBundle\\Controller\\ContactController::affichageAction',  '_route' => 'contact_platform_affichage',);
                }

                // contact_platform_modification
                if ($pathinfo === '/administrateur/contact/modification') {
                    return array (  '_controller' => 'Contact\\PlatformBundle\\Controller\\ContactController::modificationAction',  '_route' => 'contact_platform_modification',);
                }

            }

            if (0 === strpos($pathinfo, '/administrateur/presentation')) {
                // presentation_platform_affichage
                if ($pathinfo === '/administrateur/presentation/affichage') {
                    return array (  '_controller' => 'Presentation\\PlatformBundle\\Controller\\PresentationController::affichageAction',  '_route' => 'presentation_platform_affichage',);
                }

                // presentation_platform_modification
                if ($pathinfo === '/administrateur/presentation/modification') {
                    return array (  '_controller' => 'Presentation\\PlatformBundle\\Controller\\PresentationController::modificationAction',  '_route' => 'presentation_platform_modification',);
                }

            }

            if (0 === strpos($pathinfo, '/administrateur/accueil')) {
                // accueil_platform_affichage_listePhoto
                if ($pathinfo === '/administrateur/accueil/liste/photo') {
                    return array (  '_controller' => 'Accueil\\PlatformBundle\\Controller\\AccueilController::affichage_listePhotoAction',  '_route' => 'accueil_platform_affichage_listePhoto',);
                }

                // accueil_platform_ajout_photo
                if ($pathinfo === '/administrateur/accueil/ajout/photo') {
                    return array (  '_controller' => 'Accueil\\PlatformBundle\\Controller\\AccueilController::ajout_photoAction',  '_route' => 'accueil_platform_ajout_photo',);
                }

                // accueil_platform_suppression_photo
                if ($pathinfo === '/administrateur/accueil/suppression/photo') {
                    return array (  '_controller' => 'Accueil\\PlatformBundle\\Controller\\AccueilController::suppression_photoAction',  '_route' => 'accueil_platform_suppression_photo',);
                }

            }

            // accueil_platform_trie_listePhoto
            if (rtrim($pathinfo, '/') === '/administrateur') {
                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'accueil_platform_trie_listePhoto');
                }

                return array (  '_controller' => 'Accueil\\PlatformBundle\\Controller\\AccueilController::trie_listePhotoAction',  '_route' => 'accueil_platform_trie_listePhoto',);
            }

        }

        // accueil_platform_homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'accueil_platform_homepage');
            }

            return array (  '_controller' => 'Accueil\\PlatformBundle\\Controller\\AccueilController::frontAction',  '_route' => 'accueil_platform_homepage',);
        }

        // user_platform_homepage
        if (rtrim($pathinfo, '/') === '/user') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', 'user_platform_homepage');
            }

            return array (  '_controller' => 'User\\PlatformBundle\\Controller\\DefaultController::indexAction',  '_route' => 'user_platform_homepage',);
        }

        if (0 === strpos($pathinfo, '/log')) {
            if (0 === strpos($pathinfo, '/login')) {
                // fos_user_security_login
                if ($pathinfo === '/login') {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_fos_user_security_login;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\SecurityController::loginAction',  '_route' => 'fos_user_security_login',);
                }
                not_fos_user_security_login:

                // fos_user_security_check
                if ($pathinfo === '/login_check') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_fos_user_security_check;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\SecurityController::checkAction',  '_route' => 'fos_user_security_check',);
                }
                not_fos_user_security_check:

            }

            // fos_user_security_logout
            if ($pathinfo === '/logout') {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_fos_user_security_logout;
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\SecurityController::logoutAction',  '_route' => 'fos_user_security_logout',);
            }
            not_fos_user_security_logout:

        }

        if (0 === strpos($pathinfo, '/profile')) {
            // fos_user_profile_show
            if (rtrim($pathinfo, '/') === '/profile') {
                if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'HEAD'));
                    goto not_fos_user_profile_show;
                }

                if (substr($pathinfo, -1) !== '/') {
                    return $this->redirect($pathinfo.'/', 'fos_user_profile_show');
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ProfileController::showAction',  '_route' => 'fos_user_profile_show',);
            }
            not_fos_user_profile_show:

            // fos_user_profile_edit
            if ($pathinfo === '/profile/edit') {
                if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                    $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                    goto not_fos_user_profile_edit;
                }

                return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ProfileController::editAction',  '_route' => 'fos_user_profile_edit',);
            }
            not_fos_user_profile_edit:

        }

        if (0 === strpos($pathinfo, '/re')) {
            if (0 === strpos($pathinfo, '/register')) {
                // fos_user_registration_register
                if (rtrim($pathinfo, '/') === '/register') {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_fos_user_registration_register;
                    }

                    if (substr($pathinfo, -1) !== '/') {
                        return $this->redirect($pathinfo.'/', 'fos_user_registration_register');
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::registerAction',  '_route' => 'fos_user_registration_register',);
                }
                not_fos_user_registration_register:

                if (0 === strpos($pathinfo, '/register/c')) {
                    // fos_user_registration_check_email
                    if ($pathinfo === '/register/check-email') {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_fos_user_registration_check_email;
                        }

                        return array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::checkEmailAction',  '_route' => 'fos_user_registration_check_email',);
                    }
                    not_fos_user_registration_check_email:

                    if (0 === strpos($pathinfo, '/register/confirm')) {
                        // fos_user_registration_confirm
                        if (preg_match('#^/register/confirm/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                                $allow = array_merge($allow, array('GET', 'HEAD'));
                                goto not_fos_user_registration_confirm;
                            }

                            return $this->mergeDefaults(array_replace($matches, array('_route' => 'fos_user_registration_confirm')), array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::confirmAction',));
                        }
                        not_fos_user_registration_confirm:

                        // fos_user_registration_confirmed
                        if ($pathinfo === '/register/confirmed') {
                            if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                                $allow = array_merge($allow, array('GET', 'HEAD'));
                                goto not_fos_user_registration_confirmed;
                            }

                            return array (  '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::confirmedAction',  '_route' => 'fos_user_registration_confirmed',);
                        }
                        not_fos_user_registration_confirmed:

                    }

                }

            }

            if (0 === strpos($pathinfo, '/resetting')) {
                // fos_user_resetting_request
                if ($pathinfo === '/resetting/request') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_fos_user_resetting_request;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::requestAction',  '_route' => 'fos_user_resetting_request',);
                }
                not_fos_user_resetting_request:

                // fos_user_resetting_send_email
                if ($pathinfo === '/resetting/send-email') {
                    if ($this->context->getMethod() != 'POST') {
                        $allow[] = 'POST';
                        goto not_fos_user_resetting_send_email;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::sendEmailAction',  '_route' => 'fos_user_resetting_send_email',);
                }
                not_fos_user_resetting_send_email:

                // fos_user_resetting_check_email
                if ($pathinfo === '/resetting/check-email') {
                    if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'HEAD'));
                        goto not_fos_user_resetting_check_email;
                    }

                    return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::checkEmailAction',  '_route' => 'fos_user_resetting_check_email',);
                }
                not_fos_user_resetting_check_email:

                // fos_user_resetting_reset
                if (0 === strpos($pathinfo, '/resetting/reset') && preg_match('#^/resetting/reset/(?P<token>[^/]++)$#s', $pathinfo, $matches)) {
                    if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                        $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                        goto not_fos_user_resetting_reset;
                    }

                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'fos_user_resetting_reset')), array (  '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::resetAction',));
                }
                not_fos_user_resetting_reset:

            }

        }

        // fos_user_change_password
        if ($pathinfo === '/profile/change-password') {
            if (!in_array($this->context->getMethod(), array('GET', 'POST', 'HEAD'))) {
                $allow = array_merge($allow, array('GET', 'POST', 'HEAD'));
                goto not_fos_user_change_password;
            }

            return array (  '_controller' => 'FOS\\UserBundle\\Controller\\ChangePasswordController::changePasswordAction',  '_route' => 'fos_user_change_password',);
        }
        not_fos_user_change_password:

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
