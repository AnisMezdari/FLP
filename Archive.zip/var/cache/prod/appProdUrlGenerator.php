<?php

use Symfony\Component\Routing\RequestContext;
use Symfony\Component\Routing\Exception\RouteNotFoundException;
use Psr\Log\LoggerInterface;

/**
 * appProdUrlGenerator
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdUrlGenerator extends Symfony\Component\Routing\Generator\UrlGenerator
{
    private static $declaredRoutes;

    /**
     * Constructor.
     */
    public function __construct(RequestContext $context, LoggerInterface $logger = null)
    {
        $this->context = $context;
        $this->logger = $logger;
        if (null === self::$declaredRoutes) {
            self::$declaredRoutes = array(
        'evenement_platform_homepage' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'EvenementPlatformBundle:Evenemnt:affichage',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/administrateur/evenement/affichage',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'tarif_platform_affichage' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'Tarif\\PlatformBundle\\Controller\\TarifController::affichageAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/administrateur/tarif/affichage',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'tarif_platform_modification' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'Tarif\\PlatformBundle\\Controller\\TarifController::modificationAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/administrateur/tarif/modification',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'tarif_platform_ajout' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'Tarif\\PlatformBundle\\Controller\\TarifController::ajoutAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/administrateur/tarif/ajout',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'portfolio_platform_affichage' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'Portfolio\\PlatformBundle\\Controller\\PortfolioController::affichageAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/administrateur/portfolio/affichage',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'portfolio_platform_modification' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'Portfolio\\PlatformBundle\\Controller\\PortfolioController::modificationAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/administrateur/portfolio/modification',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'portfolio_platform_modificationCategorie' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'Portfolio\\PlatformBundle\\Controller\\PortfolioController::modificationCategorieAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/administrateur/portfolio/modification/categorie',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'portfolio_platform_affichageImageParCategorie' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'Portfolio\\PlatformBundle\\Controller\\PortfolioController::affichageParCategorieAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/administrateur/portfolio/affichage/image',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'portfolio_platform_ajoutImageParCategorie' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'Portfolio\\PlatformBundle\\Controller\\PortfolioController::ajoutImageParCategorieAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/administrateur/portfolio/ajout/image',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'portfolio_platform_suppressionImageParCategorie' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'Portfolio\\PlatformBundle\\Controller\\PortfolioController::modificationCategorieAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/administrateur/portfolio/suppression/image',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'contact_platform_affichage' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'Contact\\PlatformBundle\\Controller\\ContactController::affichageAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/administrateur/contact/affichage',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'contact_platform_modification' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'Contact\\PlatformBundle\\Controller\\ContactController::modificationAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/administrateur/contact/modification',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'presentation_platform_affichage' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'Presentation\\PlatformBundle\\Controller\\PresentationController::affichageAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/administrateur/presentation/affichage',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'presentation_platform_modification' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'Presentation\\PlatformBundle\\Controller\\PresentationController::modificationAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/administrateur/presentation/modification',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'accueil_platform_affichage_listePhoto' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'Accueil\\PlatformBundle\\Controller\\AccueilController::affichage_listePhotoAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/administrateur/accueil/liste/photo',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'accueil_platform_ajout_photo' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'Accueil\\PlatformBundle\\Controller\\AccueilController::ajout_photoAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/administrateur/accueil/ajout/photo',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'accueil_platform_suppression_photo' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'Accueil\\PlatformBundle\\Controller\\AccueilController::suppression_photoAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/administrateur/accueil/suppression/photo',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'accueil_platform_trie_listePhoto' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'Accueil\\PlatformBundle\\Controller\\AccueilController::trie_listePhotoAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/administrateur/',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'accueil_platform_homepage' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'Accueil\\PlatformBundle\\Controller\\AccueilController::frontAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'user_platform_homepage' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'User\\PlatformBundle\\Controller\\DefaultController::indexAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/user/',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'fos_user_security_login' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FOS\\UserBundle\\Controller\\SecurityController::loginAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/login',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'fos_user_security_check' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FOS\\UserBundle\\Controller\\SecurityController::checkAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/login_check',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'fos_user_security_logout' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FOS\\UserBundle\\Controller\\SecurityController::logoutAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/logout',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'fos_user_profile_show' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FOS\\UserBundle\\Controller\\ProfileController::showAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/profile/',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'fos_user_profile_edit' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FOS\\UserBundle\\Controller\\ProfileController::editAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/profile/edit',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'fos_user_registration_register' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::registerAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/register/',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'fos_user_registration_check_email' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::checkEmailAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/register/check-email',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'fos_user_registration_confirm' => array (  0 =>   array (    0 => 'token',  ),  1 =>   array (    '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::confirmAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'token',    ),    1 =>     array (      0 => 'text',      1 => '/register/confirm',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'fos_user_registration_confirmed' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FOS\\UserBundle\\Controller\\RegistrationController::confirmedAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/register/confirmed',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'fos_user_resetting_request' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::requestAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/resetting/request',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'fos_user_resetting_send_email' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::sendEmailAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/resetting/send-email',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'fos_user_resetting_check_email' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::checkEmailAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/resetting/check-email',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'fos_user_resetting_reset' => array (  0 =>   array (    0 => 'token',  ),  1 =>   array (    '_controller' => 'FOS\\UserBundle\\Controller\\ResettingController::resetAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'variable',      1 => '/',      2 => '[^/]++',      3 => 'token',    ),    1 =>     array (      0 => 'text',      1 => '/resetting/reset',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
        'fos_user_change_password' => array (  0 =>   array (  ),  1 =>   array (    '_controller' => 'FOS\\UserBundle\\Controller\\ChangePasswordController::changePasswordAction',  ),  2 =>   array (  ),  3 =>   array (    0 =>     array (      0 => 'text',      1 => '/profile/change-password',    ),  ),  4 =>   array (  ),  5 =>   array (  ),),
    );
        }
    }

    public function generate($name, $parameters = array(), $referenceType = self::ABSOLUTE_PATH)
    {
        if (!isset(self::$declaredRoutes[$name])) {
            throw new RouteNotFoundException(sprintf('Unable to generate a URL for the named route "%s" as such route does not exist.', $name));
        }

        list($variables, $defaults, $requirements, $tokens, $hostTokens, $requiredSchemes) = self::$declaredRoutes[$name];

        return $this->doGenerate($variables, $defaults, $requirements, $tokens, $parameters, $name, $referenceType, $hostTokens, $requiredSchemes);
    }
}
