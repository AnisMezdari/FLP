<?php

/* @Framework/Form/money_widget.html.php */
class __TwigTemplate_a665c0c65f7939a0c347c6bad91c3bb14ef5f2c7863d3d9670739a382df7742c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cb97b96ad2d0488161520ef8c50c76855e4689ce67684151793a2ad1143119c7 = $this->env->getExtension("native_profiler");
        $__internal_cb97b96ad2d0488161520ef8c50c76855e4689ce67684151793a2ad1143119c7->enter($__internal_cb97b96ad2d0488161520ef8c50c76855e4689ce67684151793a2ad1143119c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/money_widget.html.php"));

        // line 1
        echo "<?php echo str_replace('";
        echo twig_escape_filter($this->env, (isset($context["widget"]) ? $context["widget"] : $this->getContext($context, "widget")), "html", null, true);
        echo "', \$view['form']->block(\$form, 'form_widget_simple'), \$money_pattern) ?>
";
        
        $__internal_cb97b96ad2d0488161520ef8c50c76855e4689ce67684151793a2ad1143119c7->leave($__internal_cb97b96ad2d0488161520ef8c50c76855e4689ce67684151793a2ad1143119c7_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/money_widget.html.php";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo str_replace('{{ widget }}', $view['form']->block($form, 'form_widget_simple'), $money_pattern) ?>*/
/* */
