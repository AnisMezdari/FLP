<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_9fddbdb51e996b5517f2b718c8ee04c7b3edb8629ceab9ce503ab05fd1f5b2cc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4a170b699067df1ae15360df633243f0cd0779d3cdddc81682c3ca33f246b3a5 = $this->env->getExtension("native_profiler");
        $__internal_4a170b699067df1ae15360df633243f0cd0779d3cdddc81682c3ca33f246b3a5->enter($__internal_4a170b699067df1ae15360df633243f0cd0779d3cdddc81682c3ca33f246b3a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_4a170b699067df1ae15360df633243f0cd0779d3cdddc81682c3ca33f246b3a5->leave($__internal_4a170b699067df1ae15360df633243f0cd0779d3cdddc81682c3ca33f246b3a5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($form->vars['multipart']): ?>enctype="multipart/form-data"<?php endif ?>*/
/* */
