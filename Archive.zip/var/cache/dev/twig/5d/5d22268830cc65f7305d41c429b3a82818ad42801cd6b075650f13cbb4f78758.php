<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_60f1857712c8d14e877114bd00c3b0d7943701d9a5563ffe697b4f40b7b4ccfc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_718102a03c96e7a5dd3a5da1f4d73f7cc2b22aa592dc64d231306e7addbea453 = $this->env->getExtension("native_profiler");
        $__internal_718102a03c96e7a5dd3a5da1f4d73f7cc2b22aa592dc64d231306e7addbea453->enter($__internal_718102a03c96e7a5dd3a5da1f4d73f7cc2b22aa592dc64d231306e7addbea453_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_718102a03c96e7a5dd3a5da1f4d73f7cc2b22aa592dc64d231306e7addbea453->leave($__internal_718102a03c96e7a5dd3a5da1f4d73f7cc2b22aa592dc64d231306e7addbea453_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'submit')) ?>*/
/* */
