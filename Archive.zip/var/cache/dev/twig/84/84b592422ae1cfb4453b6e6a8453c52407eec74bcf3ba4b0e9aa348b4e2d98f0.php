<?php

/* FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig */
class __TwigTemplate_5b58cfb97802148883727631a355299218cd505a845aaf522d963ece5aa7c8da extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ce8ac81f28b0ce3abb03d9d434f97daf95e11d2544cd47620e8434b448e252b3 = $this->env->getExtension("native_profiler");
        $__internal_ce8ac81f28b0ce3abb03d9d434f97daf95e11d2544cd47620e8434b448e252b3->enter($__internal_ce8ac81f28b0ce3abb03d9d434f97daf95e11d2544cd47620e8434b448e252b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ce8ac81f28b0ce3abb03d9d434f97daf95e11d2544cd47620e8434b448e252b3->leave($__internal_ce8ac81f28b0ce3abb03d9d434f97daf95e11d2544cd47620e8434b448e252b3_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_9d167cac98506f7a51a038ae18b1b3c9b0b6c14129e2a16c10f208b876685467 = $this->env->getExtension("native_profiler");
        $__internal_9d167cac98506f7a51a038ae18b1b3c9b0b6c14129e2a16c10f208b876685467->enter($__internal_9d167cac98506f7a51a038ae18b1b3c9b0b6c14129e2a16c10f208b876685467_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "<p>";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("resetting.password_already_requested", array(), "FOSUserBundle"), "html", null, true);
        echo "</p>
";
        
        $__internal_9d167cac98506f7a51a038ae18b1b3c9b0b6c14129e2a16c10f208b876685467->leave($__internal_9d167cac98506f7a51a038ae18b1b3c9b0b6c14129e2a16c10f208b876685467_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:passwordAlreadyRequested.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 6,  34 => 5,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* */
/* {% block fos_user_content %}*/
/* <p>{{ 'resetting.password_already_requested'|trans }}</p>*/
/* {% endblock fos_user_content %}*/
/* */
