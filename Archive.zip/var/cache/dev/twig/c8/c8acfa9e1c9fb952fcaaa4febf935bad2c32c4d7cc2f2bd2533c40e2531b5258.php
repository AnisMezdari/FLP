<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_87285b5b3d29661081d35528f98a4e636511c23511796381f84b35440cd9aece extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a405b5bcf8f901e79fd79644d9cc18a9989e9d8dc4f0dfa71033a1bb3f137513 = $this->env->getExtension("native_profiler");
        $__internal_a405b5bcf8f901e79fd79644d9cc18a9989e9d8dc4f0dfa71033a1bb3f137513->enter($__internal_a405b5bcf8f901e79fd79644d9cc18a9989e9d8dc4f0dfa71033a1bb3f137513_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_a405b5bcf8f901e79fd79644d9cc18a9989e9d8dc4f0dfa71033a1bb3f137513->leave($__internal_a405b5bcf8f901e79fd79644d9cc18a9989e9d8dc4f0dfa71033a1bb3f137513_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
