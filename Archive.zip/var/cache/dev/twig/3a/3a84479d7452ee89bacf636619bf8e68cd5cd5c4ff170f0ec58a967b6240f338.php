<?php

/* @Framework/FormTable/form_widget_compound.html.php */
class __TwigTemplate_9952ec5b97c4cb5b78263ec00c89c78384e1b6023383a98c6ed6a6dec4625a05 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a78655248230cc88aefcf27e3de486f2d49e9b4a1dd09747eedcb1458e6f9f18 = $this->env->getExtension("native_profiler");
        $__internal_a78655248230cc88aefcf27e3de486f2d49e9b4a1dd09747eedcb1458e6f9f18->enter($__internal_a78655248230cc88aefcf27e3de486f2d49e9b4a1dd09747eedcb1458e6f9f18_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        // line 1
        echo "<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
";
        
        $__internal_a78655248230cc88aefcf27e3de486f2d49e9b4a1dd09747eedcb1458e6f9f18->leave($__internal_a78655248230cc88aefcf27e3de486f2d49e9b4a1dd09747eedcb1458e6f9f18_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <table <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/*     <?php if (!$form->parent && $errors): ?>*/
/*     <tr>*/
/*         <td colspan="2">*/
/*             <?php echo $view['form']->errors($form) ?>*/
/*         </td>*/
/*     </tr>*/
/*     <?php endif ?>*/
/*     <?php echo $view['form']->block($form, 'form_rows') ?>*/
/*     <?php echo $view['form']->rest($form) ?>*/
/* </table>*/
/* */
