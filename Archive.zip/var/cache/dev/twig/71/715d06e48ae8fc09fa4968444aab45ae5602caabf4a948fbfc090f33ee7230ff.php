<?php

/* TwigBundle:Exception:exception.js.twig */
class __TwigTemplate_5ecc595cf4856ada25bfc21f375378e6433c5ac175e9ae07549bf5bfeb87b465 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7297fc228e2e44ab1d6eb3526a915e06970f8e837237fed76302cfcb88dee471 = $this->env->getExtension("native_profiler");
        $__internal_7297fc228e2e44ab1d6eb3526a915e06970f8e837237fed76302cfcb88dee471->enter($__internal_7297fc228e2e44ab1d6eb3526a915e06970f8e837237fed76302cfcb88dee471_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "TwigBundle:Exception:exception.js.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_7297fc228e2e44ab1d6eb3526a915e06970f8e837237fed76302cfcb88dee471->leave($__internal_7297fc228e2e44ab1d6eb3526a915e06970f8e837237fed76302cfcb88dee471_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}*/
/* *//* */
/* */
