<?php

/* FOSUserBundle:Group:edit.html.twig */
class __TwigTemplate_152ab4875348be90676ff2a197331275eadc612cbf70ba2fce53ae9458649a0c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cdf4c061db1dc7e08f1e995f463015307f079918b961736e914198ebb434d2b3 = $this->env->getExtension("native_profiler");
        $__internal_cdf4c061db1dc7e08f1e995f463015307f079918b961736e914198ebb434d2b3->enter($__internal_cdf4c061db1dc7e08f1e995f463015307f079918b961736e914198ebb434d2b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_cdf4c061db1dc7e08f1e995f463015307f079918b961736e914198ebb434d2b3->leave($__internal_cdf4c061db1dc7e08f1e995f463015307f079918b961736e914198ebb434d2b3_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_0955f9239c901485e7986c82923a2c7423ffa4c99b60e18b1a57349644662c37 = $this->env->getExtension("native_profiler");
        $__internal_0955f9239c901485e7986c82923a2c7423ffa4c99b60e18b1a57349644662c37->enter($__internal_0955f9239c901485e7986c82923a2c7423ffa4c99b60e18b1a57349644662c37_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:edit_content.html.twig", "FOSUserBundle:Group:edit.html.twig", 4)->display($context);
        
        $__internal_0955f9239c901485e7986c82923a2c7423ffa4c99b60e18b1a57349644662c37->leave($__internal_0955f9239c901485e7986c82923a2c7423ffa4c99b60e18b1a57349644662c37_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:edit_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
