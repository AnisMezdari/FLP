<?php

/* @Framework/Form/choice_widget.html.php */
class __TwigTemplate_188cf95a00c69e9245f8bcea70f033ecad0cf5d4e3d1202fc22ba41176f54801 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b73663cda38bc06f42c1bfcd5c59f57e50020c3e8889fc8902a43787e6c4914e = $this->env->getExtension("native_profiler");
        $__internal_b73663cda38bc06f42c1bfcd5c59f57e50020c3e8889fc8902a43787e6c4914e->enter($__internal_b73663cda38bc06f42c1bfcd5c59f57e50020c3e8889fc8902a43787e6c4914e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        // line 1
        echo "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
        
        $__internal_b73663cda38bc06f42c1bfcd5c59f57e50020c3e8889fc8902a43787e6c4914e->leave($__internal_b73663cda38bc06f42c1bfcd5c59f57e50020c3e8889fc8902a43787e6c4914e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($expanded): ?>*/
/* <?php echo $view['form']->block($form, 'choice_widget_expanded') ?>*/
/* <?php else: ?>*/
/* <?php echo $view['form']->block($form, 'choice_widget_collapsed') ?>*/
/* <?php endif ?>*/
/* */
