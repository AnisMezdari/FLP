<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_c7745410ab641787404b506c187037572e504a045825e82ba948bc05784bb322 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_41e140940015260d1c0a7071619e5c8d76b076c814c9d42263b296c3b1b9937d = $this->env->getExtension("native_profiler");
        $__internal_41e140940015260d1c0a7071619e5c8d76b076c814c9d42263b296c3b1b9937d->enter($__internal_41e140940015260d1c0a7071619e5c8d76b076c814c9d42263b296c3b1b9937d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_41e140940015260d1c0a7071619e5c8d76b076c814c9d42263b296c3b1b9937d->leave($__internal_41e140940015260d1c0a7071619e5c8d76b076c814c9d42263b296c3b1b9937d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'choice_widget_options') ?>*/
/* */
