<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_e4a25388d97456dc19ae30666b5042f1585db1be36ce0c6169dd393dfee0c200 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5db3d9c7c3f95c98a90c5f34636bac3f93f39f11e97971d14db96573e2df65f0 = $this->env->getExtension("native_profiler");
        $__internal_5db3d9c7c3f95c98a90c5f34636bac3f93f39f11e97971d14db96573e2df65f0->enter($__internal_5db3d9c7c3f95c98a90c5f34636bac3f93f39f11e97971d14db96573e2df65f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_5db3d9c7c3f95c98a90c5f34636bac3f93f39f11e97971d14db96573e2df65f0->leave($__internal_5db3d9c7c3f95c98a90c5f34636bac3f93f39f11e97971d14db96573e2df65f0_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->widget($form) ?>*/
/* */
