<?php

/* ContactPlatformBundle:Contact:index.html.twig */
class __TwigTemplate_d1fcfb9632a0270c5a3e92ccf6b335e58611383b3414831013b8e1fc8b0e6b9c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "ContactPlatformBundle:Contact:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8e735928b0a30c5d4290b367f5c7d6c3982a035ed6ba24fcb6073f82d874cc10 = $this->env->getExtension("native_profiler");
        $__internal_8e735928b0a30c5d4290b367f5c7d6c3982a035ed6ba24fcb6073f82d874cc10->enter($__internal_8e735928b0a30c5d4290b367f5c7d6c3982a035ed6ba24fcb6073f82d874cc10_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "ContactPlatformBundle:Contact:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8e735928b0a30c5d4290b367f5c7d6c3982a035ed6ba24fcb6073f82d874cc10->leave($__internal_8e735928b0a30c5d4290b367f5c7d6c3982a035ed6ba24fcb6073f82d874cc10_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_4f0047bb8075325de9147935b3cd0a1f419f6e2f99f231dfea8e241ff1654981 = $this->env->getExtension("native_profiler");
        $__internal_4f0047bb8075325de9147935b3cd0a1f419f6e2f99f231dfea8e241ff1654981->enter($__internal_4f0047bb8075325de9147935b3cd0a1f419f6e2f99f231dfea8e241ff1654981_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
\t<form action = \"";
        // line 5
        echo $this->env->getExtension('routing')->getPath("contact_platform_modification");
        echo "\" method = \"post\" class = \"conteneurContact\" enctype=\"multipart/form-data\">
\t\t<h1 class = \"titreContact\"> Contact </h1>

\t\t<div class = \"conteneurbouton\">
\t\t\t<input type = \"submit\" name = \"boutonModifier\" value = \"Modifier\" />
\t\t</div>

\t\t<div class = \"conteneurContactImage\">
\t\t\t<img src = \"";
        // line 13
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), "urlImage", array()), "html", null, true);
        echo "\" alt = \"Image de l'entreprise\" class = \"imageContact\" />
\t\t\t<input type = \"file\" name = \"image\" class = \"boutonImageContact\" />
\t\t</div>

\t\t<div class = \"conteneurContactFormulaire\">
\t\t\t<div>
\t\t\t\t<input type = \"text\" name = \"titre\" value = \"";
        // line 19
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), "titre", array()), "html", null, true);
        echo "\" class = \"form-control\"/>
\t\t\t</div>
\t\t\t<div>
\t\t\t\t<input type = \"text\" name = \"adresse\" value = \"";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), "adresse", array()), "html", null, true);
        echo "\" class = \"form-control\" />
\t\t\t</div>
\t\t\t<div>
\t\t\t\t<input type = \"text\" name = \"email\" value = \"";
        // line 25
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), "email", array()), "html", null, true);
        echo "\" class = \"form-control\" />
\t\t\t</div>
\t\t\t<div>
\t\t\t\t<input type = \"text\" name = \"tel\" value = \"";
        // line 28
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), "telephone", array()), "html", null, true);
        echo "\" class = \"form-control\"/>
\t\t\t</div>
\t\t\t<div>
\t\t\t\t<input type = \"text\" name = \"telFixe\" value = \"";
        // line 31
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["contact"]) ? $context["contact"] : $this->getContext($context, "contact")), "telephoneFixe", array()), "html", null, true);
        echo "\" class = \"form-control\"/>
\t\t\t</div>
\t\t</div>
\t</form>

";
        
        $__internal_4f0047bb8075325de9147935b3cd0a1f419f6e2f99f231dfea8e241ff1654981->leave($__internal_4f0047bb8075325de9147935b3cd0a1f419f6e2f99f231dfea8e241ff1654981_prof);

    }

    public function getTemplateName()
    {
        return "ContactPlatformBundle:Contact:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  87 => 31,  81 => 28,  75 => 25,  69 => 22,  63 => 19,  54 => 13,  43 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "::base.html.twig" %}*/
/* */
/* {% block body %}*/
/* */
/* 	<form action = "{{path('contact_platform_modification')}}" method = "post" class = "conteneurContact" enctype="multipart/form-data">*/
/* 		<h1 class = "titreContact"> Contact </h1>*/
/* */
/* 		<div class = "conteneurbouton">*/
/* 			<input type = "submit" name = "boutonModifier" value = "Modifier" />*/
/* 		</div>*/
/* */
/* 		<div class = "conteneurContactImage">*/
/* 			<img src = "{{contact.urlImage}}" alt = "Image de l'entreprise" class = "imageContact" />*/
/* 			<input type = "file" name = "image" class = "boutonImageContact" />*/
/* 		</div>*/
/* */
/* 		<div class = "conteneurContactFormulaire">*/
/* 			<div>*/
/* 				<input type = "text" name = "titre" value = "{{contact.titre}}" class = "form-control"/>*/
/* 			</div>*/
/* 			<div>*/
/* 				<input type = "text" name = "adresse" value = "{{contact.adresse}}" class = "form-control" />*/
/* 			</div>*/
/* 			<div>*/
/* 				<input type = "text" name = "email" value = "{{contact.email}}" class = "form-control" />*/
/* 			</div>*/
/* 			<div>*/
/* 				<input type = "text" name = "tel" value = "{{contact.telephone}}" class = "form-control"/>*/
/* 			</div>*/
/* 			<div>*/
/* 				<input type = "text" name = "telFixe" value = "{{contact.telephoneFixe}}" class = "form-control"/>*/
/* 			</div>*/
/* 		</div>*/
/* 	</form>*/
/* */
/* {% endblock %}*/
