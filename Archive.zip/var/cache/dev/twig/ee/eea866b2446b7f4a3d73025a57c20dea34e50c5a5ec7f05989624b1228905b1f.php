<?php

/* FOSUserBundle:Registration:register.html.twig */
class __TwigTemplate_0159b1de9c97e3eebe434d4210ee7bbce3beb8b203fba3a63965ce858faf1d38 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Registration:register.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_58b517187649765f173a33df53ded3536a2439735bcea9e1d09a345416daa923 = $this->env->getExtension("native_profiler");
        $__internal_58b517187649765f173a33df53ded3536a2439735bcea9e1d09a345416daa923->enter($__internal_58b517187649765f173a33df53ded3536a2439735bcea9e1d09a345416daa923_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:register.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_58b517187649765f173a33df53ded3536a2439735bcea9e1d09a345416daa923->leave($__internal_58b517187649765f173a33df53ded3536a2439735bcea9e1d09a345416daa923_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_37e108d11f391ae92061805b055b2a72e0a5d4b622ff6de5227926e79c8e1272 = $this->env->getExtension("native_profiler");
        $__internal_37e108d11f391ae92061805b055b2a72e0a5d4b622ff6de5227926e79c8e1272->enter($__internal_37e108d11f391ae92061805b055b2a72e0a5d4b622ff6de5227926e79c8e1272_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Registration:register_content.html.twig", "FOSUserBundle:Registration:register.html.twig", 4)->display($context);
        
        $__internal_37e108d11f391ae92061805b055b2a72e0a5d4b622ff6de5227926e79c8e1272->leave($__internal_37e108d11f391ae92061805b055b2a72e0a5d4b622ff6de5227926e79c8e1272_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:register.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Registration:register_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
