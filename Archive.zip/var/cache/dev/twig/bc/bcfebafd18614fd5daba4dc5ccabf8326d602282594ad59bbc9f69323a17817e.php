<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_0cb4afc6b1e63729c35fc5b2346c805ee203eac09ea8f32b16aa0f7ed224e6e5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_026a5ca194749568316170f3bae10f93b575ebff937c71ad196d01e001c69878 = $this->env->getExtension("native_profiler");
        $__internal_026a5ca194749568316170f3bae10f93b575ebff937c71ad196d01e001c69878->enter($__internal_026a5ca194749568316170f3bae10f93b575ebff937c71ad196d01e001c69878_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_026a5ca194749568316170f3bae10f93b575ebff937c71ad196d01e001c69878->leave($__internal_026a5ca194749568316170f3bae10f93b575ebff937c71ad196d01e001c69878_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */
