<?php

/* FOSUserBundle:Registration:email.txt.twig */
class __TwigTemplate_d6880b2748fd0ebee160b8f0cfd0f577818eae5a2c3f9b95c9ba140080eecbd3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b97b3664176dc60d2a966e378d6e6eca77d0162660836069f888b5219f5f2e12 = $this->env->getExtension("native_profiler");
        $__internal_b97b3664176dc60d2a966e378d6e6eca77d0162660836069f888b5219f5f2e12->enter($__internal_b97b3664176dc60d2a966e378d6e6eca77d0162660836069f888b5219f5f2e12_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Registration:email.txt.twig"));

        // line 2
        $this->displayBlock('subject', $context, $blocks);
        // line 7
        $this->displayBlock('body_text', $context, $blocks);
        // line 12
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_b97b3664176dc60d2a966e378d6e6eca77d0162660836069f888b5219f5f2e12->leave($__internal_b97b3664176dc60d2a966e378d6e6eca77d0162660836069f888b5219f5f2e12_prof);

    }

    // line 2
    public function block_subject($context, array $blocks = array())
    {
        $__internal_49513af63d9dcecfd6e90bd2e49ded0bfb595335c46d38327952c4e5b04796db = $this->env->getExtension("native_profiler");
        $__internal_49513af63d9dcecfd6e90bd2e49ded0bfb595335c46d38327952c4e5b04796db->enter($__internal_49513af63d9dcecfd6e90bd2e49ded0bfb595335c46d38327952c4e5b04796db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 4
        echo $this->env->getExtension('translator')->trans("registration.email.subject", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_49513af63d9dcecfd6e90bd2e49ded0bfb595335c46d38327952c4e5b04796db->leave($__internal_49513af63d9dcecfd6e90bd2e49ded0bfb595335c46d38327952c4e5b04796db_prof);

    }

    // line 7
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_36dbcfa67871c5eacfeeb59f383ba6adda587871b67be9e1c0094154a2a65f07 = $this->env->getExtension("native_profiler");
        $__internal_36dbcfa67871c5eacfeeb59f383ba6adda587871b67be9e1c0094154a2a65f07->enter($__internal_36dbcfa67871c5eacfeeb59f383ba6adda587871b67be9e1c0094154a2a65f07_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 9
        echo $this->env->getExtension('translator')->trans("registration.email.message", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_36dbcfa67871c5eacfeeb59f383ba6adda587871b67be9e1c0094154a2a65f07->leave($__internal_36dbcfa67871c5eacfeeb59f383ba6adda587871b67be9e1c0094154a2a65f07_prof);

    }

    // line 12
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_bde7146961b863905e2380f76fed2cdc4bba84f8d427ef253ff24435ff55e909 = $this->env->getExtension("native_profiler");
        $__internal_bde7146961b863905e2380f76fed2cdc4bba84f8d427ef253ff24435ff55e909->enter($__internal_bde7146961b863905e2380f76fed2cdc4bba84f8d427ef253ff24435ff55e909_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_bde7146961b863905e2380f76fed2cdc4bba84f8d427ef253ff24435ff55e909->leave($__internal_bde7146961b863905e2380f76fed2cdc4bba84f8d427ef253ff24435ff55e909_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Registration:email.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  66 => 12,  57 => 9,  51 => 7,  42 => 4,  36 => 2,  29 => 12,  27 => 7,  25 => 2,);
    }
}
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* {% block subject %}*/
/* {% autoescape false %}*/
/* {{ 'registration.email.subject'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}*/
/* {% endautoescape %}*/
/* {% endblock %}*/
/* {% block body_text %}*/
/* {% autoescape false %}*/
/* {{ 'registration.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}*/
/* {% endautoescape %}*/
/* {% endblock %}*/
/* {% block body_html %}{% endblock %}*/
/* */
