<?php

/* AccueilPlatformBundle:Accueil:index.html.twig */
class __TwigTemplate_bdf790f7cec0011bb31afc29fab8dbc1cd85b31af7be477ac96d1c11be3b47dd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "AccueilPlatformBundle:Accueil:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c9acbd9fef5699ce0c7c3f4a9c02c3f208dc16f47310b3ff99bb76c7547cee47 = $this->env->getExtension("native_profiler");
        $__internal_c9acbd9fef5699ce0c7c3f4a9c02c3f208dc16f47310b3ff99bb76c7547cee47->enter($__internal_c9acbd9fef5699ce0c7c3f4a9c02c3f208dc16f47310b3ff99bb76c7547cee47_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AccueilPlatformBundle:Accueil:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c9acbd9fef5699ce0c7c3f4a9c02c3f208dc16f47310b3ff99bb76c7547cee47->leave($__internal_c9acbd9fef5699ce0c7c3f4a9c02c3f208dc16f47310b3ff99bb76c7547cee47_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_77aed342e5ab516c3c5e88e710ef2f52745596de6f7407f432ddf449aaac38c7 = $this->env->getExtension("native_profiler");
        $__internal_77aed342e5ab516c3c5e88e710ef2f52745596de6f7407f432ddf449aaac38c7->enter($__internal_77aed342e5ab516c3c5e88e710ef2f52745596de6f7407f432ddf449aaac38c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
  <div class = \"conteneur\">

  \t<h1 class = \"titreAccueil\">Accueil</h1>
    
\t   <div class = \"conteneurBouton\">
      <input name=\"filesToUpload[]\" id=\"filesToUpload\" type=\"file\" multiple=\"\" />
      <input type=\"hidden\" value=\"";
        // line 11
        echo $this->env->getExtension('routing')->getPath("accueil_platform_ajout_photo");
        echo "\" id =  \"lienAjoutPhoto\" />
      <input name=\"bouton\" id=\"boutonUpload\" value=\"Upload\" type=\"submit\" />
      <input type=\"hidden\" id=\"lienSuppressionPhotonu2\" value=\"";
        // line 13
        echo $this->env->getExtension('routing')->getPath("accueil_platform_suppression_photo");
        echo "\" />
    </div>

  \t<div class = \"conteneurImage\" id= \"fileList\">
      ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["photos"]) ? $context["photos"] : $this->getContext($context, "photos")));
        foreach ($context['_seq'] as $context["_key"] => $context["photo"]) {
            // line 18
            echo "        <div class = \"conteneurUneImage\" id= \"img-";
            echo twig_escape_filter($this->env, $this->getAttribute($context["photo"], "id", array()), "html", null, true);
            echo "\"> 
          <img class = \"imageAccueil\" id= \"imgg-";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["photo"], "id", array()), "html", null, true);
            echo "\"  src = \"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["photo"], "urlImage", array()), "html", null, true);
            echo "\" alt = \"img\" />
          <span  id= \"";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($context["photo"], "id", array()), "html", null, true);
            echo "\" class=\"glyphicon glyphicon-remove fa-lg croixSuppression\" > </span>
          <input type=\"hidden\" value=\"";
            // line 21
            echo $this->env->getExtension('routing')->getPath("accueil_platform_suppression_photo");
            echo "\" id =  \"lienSuppressionPhoto\" />
        </div>
      ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['photo'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        echo "  \t</div>

  </div>

";
        
        $__internal_77aed342e5ab516c3c5e88e710ef2f52745596de6f7407f432ddf449aaac38c7->leave($__internal_77aed342e5ab516c3c5e88e710ef2f52745596de6f7407f432ddf449aaac38c7_prof);

    }

    public function getTemplateName()
    {
        return "AccueilPlatformBundle:Accueil:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  89 => 24,  80 => 21,  76 => 20,  70 => 19,  65 => 18,  61 => 17,  54 => 13,  49 => 11,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "::base.html.twig" %}*/
/* */
/* {% block body %}*/
/* */
/*   <div class = "conteneur">*/
/* */
/*   	<h1 class = "titreAccueil">Accueil</h1>*/
/*     */
/* 	   <div class = "conteneurBouton">*/
/*       <input name="filesToUpload[]" id="filesToUpload" type="file" multiple="" />*/
/*       <input type="hidden" value="{{ path('accueil_platform_ajout_photo') }}" id =  "lienAjoutPhoto" />*/
/*       <input name="bouton" id="boutonUpload" value="Upload" type="submit" />*/
/*       <input type="hidden" id="lienSuppressionPhotonu2" value="{{ path('accueil_platform_suppression_photo') }}" />*/
/*     </div>*/
/* */
/*   	<div class = "conteneurImage" id= "fileList">*/
/*       {% for photo in photos %}*/
/*         <div class = "conteneurUneImage" id= "img-{{photo.id}}"> */
/*           <img class = "imageAccueil" id= "imgg-{{photo.id}}"  src = "{{ photo.urlImage }}" alt = "img" />*/
/*           <span  id= "{{photo.id}}" class="glyphicon glyphicon-remove fa-lg croixSuppression" > </span>*/
/*           <input type="hidden" value="{{ path('accueil_platform_suppression_photo') }}" id =  "lienSuppressionPhoto" />*/
/*         </div>*/
/*       {% endfor %}*/
/*   	</div>*/
/* */
/*   </div>*/
/* */
/* {% endblock %}*/
