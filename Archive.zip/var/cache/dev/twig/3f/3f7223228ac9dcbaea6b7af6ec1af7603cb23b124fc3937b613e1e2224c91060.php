<?php

/* @Framework/Form/form_widget_compound.html.php */
class __TwigTemplate_a73b6a5513ba04cd5c9ae8e51cc94ea982cb8121ff10cf90d9b3b22deb452a7d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f8733e8be82ed9b44c47a446d3643cf947f357593a2f06bf09c9082c8549b1d2 = $this->env->getExtension("native_profiler");
        $__internal_f8733e8be82ed9b44c47a446d3643cf947f357593a2f06bf09c9082c8549b1d2->enter($__internal_f8733e8be82ed9b44c47a446d3643cf947f357593a2f06bf09c9082c8549b1d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
";
        
        $__internal_f8733e8be82ed9b44c47a446d3643cf947f357593a2f06bf09c9082c8549b1d2->leave($__internal_f8733e8be82ed9b44c47a446d3643cf947f357593a2f06bf09c9082c8549b1d2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/*     <?php if (!$form->parent && $errors): ?>*/
/*     <?php echo $view['form']->errors($form) ?>*/
/*     <?php endif ?>*/
/*     <?php echo $view['form']->block($form, 'form_rows') ?>*/
/*     <?php echo $view['form']->rest($form) ?>*/
/* </div>*/
/* */
