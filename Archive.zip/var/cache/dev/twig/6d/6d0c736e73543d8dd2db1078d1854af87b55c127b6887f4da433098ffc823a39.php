<?php

/* FOSUserBundle:Resetting:request.html.twig */
class __TwigTemplate_840dbcc00815ae31c7d9d903610ba47007d88b9933ea30e33e7bf8aaa813b099 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:request.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_97a05a80b01ae70ebdced80fd3168e61396f0379f4e985f20a4378d5bcc804f4 = $this->env->getExtension("native_profiler");
        $__internal_97a05a80b01ae70ebdced80fd3168e61396f0379f4e985f20a4378d5bcc804f4->enter($__internal_97a05a80b01ae70ebdced80fd3168e61396f0379f4e985f20a4378d5bcc804f4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:request.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_97a05a80b01ae70ebdced80fd3168e61396f0379f4e985f20a4378d5bcc804f4->leave($__internal_97a05a80b01ae70ebdced80fd3168e61396f0379f4e985f20a4378d5bcc804f4_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_c35e7fe82f1651dafe4cb519161ae446ec414398111094360dab8d28bfd855e7 = $this->env->getExtension("native_profiler");
        $__internal_c35e7fe82f1651dafe4cb519161ae446ec414398111094360dab8d28bfd855e7->enter($__internal_c35e7fe82f1651dafe4cb519161ae446ec414398111094360dab8d28bfd855e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Resetting:request_content.html.twig", "FOSUserBundle:Resetting:request.html.twig", 4)->display($context);
        
        $__internal_c35e7fe82f1651dafe4cb519161ae446ec414398111094360dab8d28bfd855e7->leave($__internal_c35e7fe82f1651dafe4cb519161ae446ec414398111094360dab8d28bfd855e7_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:request.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Resetting:request_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
