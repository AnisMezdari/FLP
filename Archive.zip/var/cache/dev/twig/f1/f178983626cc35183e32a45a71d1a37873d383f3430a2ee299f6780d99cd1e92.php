<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_2a76516849f0ac4e41961b2830b53cb130c426eada4d6c7b945fd7fe8144705f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_136010a15b9a3f288fb998be7ae26480bbe4dce06e09e42c6af846c219b9419d = $this->env->getExtension("native_profiler");
        $__internal_136010a15b9a3f288fb998be7ae26480bbe4dce06e09e42c6af846c219b9419d->enter($__internal_136010a15b9a3f288fb998be7ae26480bbe4dce06e09e42c6af846c219b9419d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_136010a15b9a3f288fb998be7ae26480bbe4dce06e09e42c6af846c219b9419d->leave($__internal_136010a15b9a3f288fb998be7ae26480bbe4dce06e09e42c6af846c219b9419d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'hidden')) ?>*/
/* */
