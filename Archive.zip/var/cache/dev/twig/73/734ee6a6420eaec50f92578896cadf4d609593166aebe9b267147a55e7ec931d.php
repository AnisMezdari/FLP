<?php

/* FOSUserBundle:Group:new.html.twig */
class __TwigTemplate_4a86d4577d1bc6d456b75606eb81634221bddbe82e3d9a5bed833736c40b8456 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:new.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cf47880a65ca77767c9f19d4930fa47b4ccf8c4353ddbbb88fefe581daafdea8 = $this->env->getExtension("native_profiler");
        $__internal_cf47880a65ca77767c9f19d4930fa47b4ccf8c4353ddbbb88fefe581daafdea8->enter($__internal_cf47880a65ca77767c9f19d4930fa47b4ccf8c4353ddbbb88fefe581daafdea8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_cf47880a65ca77767c9f19d4930fa47b4ccf8c4353ddbbb88fefe581daafdea8->leave($__internal_cf47880a65ca77767c9f19d4930fa47b4ccf8c4353ddbbb88fefe581daafdea8_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_0eec18d1618aafce79614f7e788e61053742a387159a80b2c9f1c686f85f9973 = $this->env->getExtension("native_profiler");
        $__internal_0eec18d1618aafce79614f7e788e61053742a387159a80b2c9f1c686f85f9973->enter($__internal_0eec18d1618aafce79614f7e788e61053742a387159a80b2c9f1c686f85f9973_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:new_content.html.twig", "FOSUserBundle:Group:new.html.twig", 4)->display($context);
        
        $__internal_0eec18d1618aafce79614f7e788e61053742a387159a80b2c9f1c686f85f9973->leave($__internal_0eec18d1618aafce79614f7e788e61053742a387159a80b2c9f1c686f85f9973_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:new_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
