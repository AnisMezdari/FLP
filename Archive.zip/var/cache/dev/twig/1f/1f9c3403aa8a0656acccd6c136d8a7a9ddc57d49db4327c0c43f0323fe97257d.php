<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_b002a19ceaf843906322a71e2b1a08f593badb50dba964a3f7ef6ea2307c8ee0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_268860f1064f3f0cb6d4ef5484a177ef9f21ce68476ce5566d192b0439fe2967 = $this->env->getExtension("native_profiler");
        $__internal_268860f1064f3f0cb6d4ef5484a177ef9f21ce68476ce5566d192b0439fe2967->enter($__internal_268860f1064f3f0cb6d4ef5484a177ef9f21ce68476ce5566d192b0439fe2967_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_268860f1064f3f0cb6d4ef5484a177ef9f21ce68476ce5566d192b0439fe2967->leave($__internal_268860f1064f3f0cb6d4ef5484a177ef9f21ce68476ce5566d192b0439fe2967_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php foreach ($form as $child): ?>*/
/*     <?php if (!$child->isRendered()): ?>*/
/*         <?php echo $view['form']->row($child) ?>*/
/*     <?php endif; ?>*/
/* <?php endforeach; ?>*/
/* */
