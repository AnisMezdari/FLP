<?php

/* ::baseFront.html.twig */
class __TwigTemplate_831f7e0c27e2dc6e2b84c67574627286e426210c8b14752a29d45057c74d3856 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'nav' => array($this, 'block_nav'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5fe7b0bd74b9b0857bc7b19c06ee6fa690ddadcb7196fc0683b46f00275991db = $this->env->getExtension("native_profiler");
        $__internal_5fe7b0bd74b9b0857bc7b19c06ee6fa690ddadcb7196fc0683b46f00275991db->enter($__internal_5fe7b0bd74b9b0857bc7b19c06ee6fa690ddadcb7196fc0683b46f00275991db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::baseFront.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <meta name=\"viewport\" content=\"width-device-width, initial-scale-1.0\">

        <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

        <link rel=\"stylesheet\" href=\"path/to/font-awesome/css/font-awesome.min.css\" />
        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("web/bundles/framework/images/logo_symfony.png"), "html", null, true);
        echo "\" />
        <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css\" />
        <link href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css\" rel=\"stylesheet\">
        <link href=\"path/to/css/fileinput.min.css\" media=\"all\" rel=\"stylesheet\" type=\"text/css\" />
        <script src=\"//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js\"></script>
        <script type=\"text/javascript\" src=\"js/bootstrap-filestyle.min.js\"> </script>

        <link rel=\"stylesheet\" href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/Base/css/baseFront.css"), "html", null, true);
        echo "\" />
        <link rel=\"stylesheet\" href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/Accueil/css/accueilFront.css"), "html", null, true);
        echo "\" />

        ";
        // line 20
        $this->displayBlock('stylesheets', $context, $blocks);
        echo " 
    </head>
    <body>

    \t<script src=\"//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\"></script>
        <script src=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js\"></script> 
        ";
        // line 26
        $this->displayBlock('nav', $context, $blocks);
        // line 27
        echo "        ";
        $this->displayBlock('body', $context, $blocks);
        // line 28
        echo "
        ";
        // line 29
        $this->displayBlock('javascripts', $context, $blocks);
        // line 30
        echo "
        <footer class = \"frontFooter\">
             Copyright © 2017 Fleur de Lys Photography Tous droits Réservés.
        </footer>
    </body>

</html>";
        
        $__internal_5fe7b0bd74b9b0857bc7b19c06ee6fa690ddadcb7196fc0683b46f00275991db->leave($__internal_5fe7b0bd74b9b0857bc7b19c06ee6fa690ddadcb7196fc0683b46f00275991db_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_9c864a0ac960a7b6bd939053f99c28011cb7c9ccebcec9b6e79f00d91bf9c7fb = $this->env->getExtension("native_profiler");
        $__internal_9c864a0ac960a7b6bd939053f99c28011cb7c9ccebcec9b6e79f00d91bf9c7fb->enter($__internal_9c864a0ac960a7b6bd939053f99c28011cb7c9ccebcec9b6e79f00d91bf9c7fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo " Fleur de Lys Photographie | ";
        
        $__internal_9c864a0ac960a7b6bd939053f99c28011cb7c9ccebcec9b6e79f00d91bf9c7fb->leave($__internal_9c864a0ac960a7b6bd939053f99c28011cb7c9ccebcec9b6e79f00d91bf9c7fb_prof);

    }

    // line 20
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_0fa132277cfedec86b8612479c90227145da966c39d1034236d5cfe208e49192 = $this->env->getExtension("native_profiler");
        $__internal_0fa132277cfedec86b8612479c90227145da966c39d1034236d5cfe208e49192->enter($__internal_0fa132277cfedec86b8612479c90227145da966c39d1034236d5cfe208e49192_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_0fa132277cfedec86b8612479c90227145da966c39d1034236d5cfe208e49192->leave($__internal_0fa132277cfedec86b8612479c90227145da966c39d1034236d5cfe208e49192_prof);

    }

    // line 26
    public function block_nav($context, array $blocks = array())
    {
        $__internal_012ccf9221a72e0f65c64d74933680ad3d03d893eeb3db79aee9880248070f72 = $this->env->getExtension("native_profiler");
        $__internal_012ccf9221a72e0f65c64d74933680ad3d03d893eeb3db79aee9880248070f72->enter($__internal_012ccf9221a72e0f65c64d74933680ad3d03d893eeb3db79aee9880248070f72_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "nav"));

        echo " ";
        $this->loadTemplate("::navFront.html.twig", "::baseFront.html.twig", 26)->display($context);
        echo " ";
        
        $__internal_012ccf9221a72e0f65c64d74933680ad3d03d893eeb3db79aee9880248070f72->leave($__internal_012ccf9221a72e0f65c64d74933680ad3d03d893eeb3db79aee9880248070f72_prof);

    }

    // line 27
    public function block_body($context, array $blocks = array())
    {
        $__internal_04dfa17095b4ab2069c03316d1d2b05182904f59eb7b427bd352a6f25d1f46e0 = $this->env->getExtension("native_profiler");
        $__internal_04dfa17095b4ab2069c03316d1d2b05182904f59eb7b427bd352a6f25d1f46e0->enter($__internal_04dfa17095b4ab2069c03316d1d2b05182904f59eb7b427bd352a6f25d1f46e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        echo "  ";
        
        $__internal_04dfa17095b4ab2069c03316d1d2b05182904f59eb7b427bd352a6f25d1f46e0->leave($__internal_04dfa17095b4ab2069c03316d1d2b05182904f59eb7b427bd352a6f25d1f46e0_prof);

    }

    // line 29
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_5f1a7b5d0f99609c92799b217a662ff1ee48de56a481848a0f06ee285d790f98 = $this->env->getExtension("native_profiler");
        $__internal_5f1a7b5d0f99609c92799b217a662ff1ee48de56a481848a0f06ee285d790f98->enter($__internal_5f1a7b5d0f99609c92799b217a662ff1ee48de56a481848a0f06ee285d790f98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_5f1a7b5d0f99609c92799b217a662ff1ee48de56a481848a0f06ee285d790f98->leave($__internal_5f1a7b5d0f99609c92799b217a662ff1ee48de56a481848a0f06ee285d790f98_prof);

    }

    public function getTemplateName()
    {
        return "::baseFront.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  141 => 29,  129 => 27,  115 => 26,  104 => 20,  92 => 7,  79 => 30,  77 => 29,  74 => 28,  71 => 27,  69 => 26,  60 => 20,  55 => 18,  51 => 17,  41 => 10,  35 => 7,  27 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <meta name="viewport" content="width-device-width, initial-scale-1.0">*/
/* */
/*         <title>{% block title %} Fleur de Lys Photographie | {% endblock %}</title>*/
/* */
/*         <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css" />*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('web/bundles/framework/images/logo_symfony.png') }}" />*/
/*         <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" />*/
/*         <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">*/
/*         <link href="path/to/css/fileinput.min.css" media="all" rel="stylesheet" type="text/css" />*/
/*         <script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>*/
/*         <script type="text/javascript" src="js/bootstrap-filestyle.min.js"> </script>*/
/* */
/*         <link rel="stylesheet" href="{{asset('bundles/Base/css/baseFront.css')}}" />*/
/*         <link rel="stylesheet" href="{{asset('bundles/Accueil/css/accueilFront.css')}}" />*/
/* */
/*         {% block stylesheets %}{% endblock %} */
/*     </head>*/
/*     <body>*/
/* */
/*     	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>*/
/*         <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script> */
/*         {% block nav %} {% include '::navFront.html.twig' %} {% endblock %}*/
/*         {% block body %}  {% endblock %}*/
/* */
/*         {% block javascripts %}{% endblock %}*/
/* */
/*         <footer class = "frontFooter">*/
/*              Copyright © 2017 Fleur de Lys Photography Tous droits Réservés.*/
/*         </footer>*/
/*     </body>*/
/* */
/* </html>*/
