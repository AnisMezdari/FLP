<?php

/* TwigBundle:Exception:error.css.twig */
class __TwigTemplate_97b955b2e4552c8663d23a3913f6dcda0a36facbb65352b9f6f74faa849b1ee1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cdfd28dead13082d9fe5dd23b91ff753f4d301b59e6bc9211dcf0cde2df8a03d = $this->env->getExtension("native_profiler");
        $__internal_cdfd28dead13082d9fe5dd23b91ff753f4d301b59e6bc9211dcf0cde2df8a03d->enter($__internal_cdfd28dead13082d9fe5dd23b91ff753f4d301b59e6bc9211dcf0cde2df8a03d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_cdfd28dead13082d9fe5dd23b91ff753f4d301b59e6bc9211dcf0cde2df8a03d->leave($__internal_cdfd28dead13082d9fe5dd23b91ff753f4d301b59e6bc9211dcf0cde2df8a03d_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {{ status_code }} {{ status_text }}*/
/* */
/* *//* */
/* */
