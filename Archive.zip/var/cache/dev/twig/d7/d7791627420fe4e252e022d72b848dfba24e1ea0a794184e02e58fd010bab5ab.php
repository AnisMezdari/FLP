<?php

/* FOSUserBundle:Resetting:checkEmail.html.twig */
class __TwigTemplate_f848895bf5ff8a715eb3cd421fe2ec6c16595a687e427af47d0bd30efb2e8593 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:checkEmail.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e2ea6f608c932486263804441e613ca6b6ce01422f517d8843c712c85723d8b4 = $this->env->getExtension("native_profiler");
        $__internal_e2ea6f608c932486263804441e613ca6b6ce01422f517d8843c712c85723d8b4->enter($__internal_e2ea6f608c932486263804441e613ca6b6ce01422f517d8843c712c85723d8b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:checkEmail.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e2ea6f608c932486263804441e613ca6b6ce01422f517d8843c712c85723d8b4->leave($__internal_e2ea6f608c932486263804441e613ca6b6ce01422f517d8843c712c85723d8b4_prof);

    }

    // line 5
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_b3d422d6346bc94de1b480a259260fd6219370b3ad8385c364c953c3b3fd3c42 = $this->env->getExtension("native_profiler");
        $__internal_b3d422d6346bc94de1b480a259260fd6219370b3ad8385c364c953c3b3fd3c42->enter($__internal_b3d422d6346bc94de1b480a259260fd6219370b3ad8385c364c953c3b3fd3c42_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 6
        echo "<p>
";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("resetting.check_email", array("%email%" => (isset($context["email"]) ? $context["email"] : $this->getContext($context, "email"))), "FOSUserBundle"), "html", null, true);
        echo "
</p>
";
        
        $__internal_b3d422d6346bc94de1b480a259260fd6219370b3ad8385c364c953c3b3fd3c42->leave($__internal_b3d422d6346bc94de1b480a259260fd6219370b3ad8385c364c953c3b3fd3c42_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:checkEmail.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  43 => 7,  40 => 6,  34 => 5,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* */
/* {% block fos_user_content %}*/
/* <p>*/
/* {{ 'resetting.check_email'|trans({'%email%': email}) }}*/
/* </p>*/
/* {% endblock %}*/
/* */
