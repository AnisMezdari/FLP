<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_8b1ae2f519b250ccda98a2e6ea50989406d1f109dc715451a00cceba9cf3964c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1e4c04ff760c781cbf7ccd2f0de2cfc6e541552421f6d0480dce25d9e03b6ceb = $this->env->getExtension("native_profiler");
        $__internal_1e4c04ff760c781cbf7ccd2f0de2cfc6e541552421f6d0480dce25d9e03b6ceb->enter($__internal_1e4c04ff760c781cbf7ccd2f0de2cfc6e541552421f6d0480dce25d9e03b6ceb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_1e4c04ff760c781cbf7ccd2f0de2cfc6e541552421f6d0480dce25d9e03b6ceb->leave($__internal_1e4c04ff760c781cbf7ccd2f0de2cfc6e541552421f6d0480dce25d9e03b6ceb_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'email')) ?>*/
/* */
