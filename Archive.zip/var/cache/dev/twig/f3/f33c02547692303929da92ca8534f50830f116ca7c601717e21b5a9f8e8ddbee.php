<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_387d497361b9856bf9edc720550a7a2290bce6ced7b2d298dfcf376ad4934f8e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_295f2edd6f31f7286a2b56fef1043362f207efec37807114051554ae6c2bb40d = $this->env->getExtension("native_profiler");
        $__internal_295f2edd6f31f7286a2b56fef1043362f207efec37807114051554ae6c2bb40d->enter($__internal_295f2edd6f31f7286a2b56fef1043362f207efec37807114051554ae6c2bb40d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_295f2edd6f31f7286a2b56fef1043362f207efec37807114051554ae6c2bb40d->leave($__internal_295f2edd6f31f7286a2b56fef1043362f207efec37807114051554ae6c2bb40d_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_9fdb26a702252028796dd0a2530789e470b176c2586c8bbfd55f379c53dc4680 = $this->env->getExtension("native_profiler");
        $__internal_9fdb26a702252028796dd0a2530789e470b176c2586c8bbfd55f379c53dc4680->enter($__internal_9fdb26a702252028796dd0a2530789e470b176c2586c8bbfd55f379c53dc4680_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_9fdb26a702252028796dd0a2530789e470b176c2586c8bbfd55f379c53dc4680->leave($__internal_9fdb26a702252028796dd0a2530789e470b176c2586c8bbfd55f379c53dc4680_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_3c89fd5cc06d3836eb83a065145fcdd079b61906b2fe4c7cd92904d7feb48d07 = $this->env->getExtension("native_profiler");
        $__internal_3c89fd5cc06d3836eb83a065145fcdd079b61906b2fe4c7cd92904d7feb48d07->enter($__internal_3c89fd5cc06d3836eb83a065145fcdd079b61906b2fe4c7cd92904d7feb48d07_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_3c89fd5cc06d3836eb83a065145fcdd079b61906b2fe4c7cd92904d7feb48d07->leave($__internal_3c89fd5cc06d3836eb83a065145fcdd079b61906b2fe4c7cd92904d7feb48d07_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  57 => 8,  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }
}
/* {% extends '@Twig/layout.html.twig' %}*/
/* */
/* {% block title 'Redirection Intercepted' %}*/
/* */
/* {% block body %}*/
/*     <div class="sf-reset">*/
/*         <div class="block-exception">*/
/*             <h1>This request redirects to <a href="{{ location }}">{{ location }}</a>.</h1>*/
/* */
/*             <p>*/
/*                 <small>*/
/*                     The redirect was intercepted by the web debug toolbar to help debugging.*/
/*                     For more information, see the "intercept-redirects" option of the Profiler.*/
/*                 </small>*/
/*             </p>*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
