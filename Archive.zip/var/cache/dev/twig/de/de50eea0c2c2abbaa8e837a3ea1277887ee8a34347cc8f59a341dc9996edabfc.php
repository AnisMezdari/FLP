<?php

/* FOSUserBundle:Resetting:email.txt.twig */
class __TwigTemplate_7ddff6be767aae4776ef35081c18e02b64ad613a98c0c4388151e1981c3ceaef extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'subject' => array($this, 'block_subject'),
            'body_text' => array($this, 'block_body_text'),
            'body_html' => array($this, 'block_body_html'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_04c4c2edd097588bd0e5aa592a995692ae24290e146747ccf89c9c442f88095e = $this->env->getExtension("native_profiler");
        $__internal_04c4c2edd097588bd0e5aa592a995692ae24290e146747ccf89c9c442f88095e->enter($__internal_04c4c2edd097588bd0e5aa592a995692ae24290e146747ccf89c9c442f88095e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:email.txt.twig"));

        // line 2
        $this->displayBlock('subject', $context, $blocks);
        // line 7
        $this->displayBlock('body_text', $context, $blocks);
        // line 12
        $this->displayBlock('body_html', $context, $blocks);
        
        $__internal_04c4c2edd097588bd0e5aa592a995692ae24290e146747ccf89c9c442f88095e->leave($__internal_04c4c2edd097588bd0e5aa592a995692ae24290e146747ccf89c9c442f88095e_prof);

    }

    // line 2
    public function block_subject($context, array $blocks = array())
    {
        $__internal_6d910f1155ac94e85599ac2d04d03bc77485bb6030c1d7e1869fe1f5c1518492 = $this->env->getExtension("native_profiler");
        $__internal_6d910f1155ac94e85599ac2d04d03bc77485bb6030c1d7e1869fe1f5c1518492->enter($__internal_6d910f1155ac94e85599ac2d04d03bc77485bb6030c1d7e1869fe1f5c1518492_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "subject"));

        // line 4
        echo $this->env->getExtension('translator')->trans("resetting.email.subject", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array())), "FOSUserBundle");
        echo "
";
        
        $__internal_6d910f1155ac94e85599ac2d04d03bc77485bb6030c1d7e1869fe1f5c1518492->leave($__internal_6d910f1155ac94e85599ac2d04d03bc77485bb6030c1d7e1869fe1f5c1518492_prof);

    }

    // line 7
    public function block_body_text($context, array $blocks = array())
    {
        $__internal_ae5b1ad06df90219ba18f5fd974c99a4ce33fc4d05a804131ff6441a5b896d99 = $this->env->getExtension("native_profiler");
        $__internal_ae5b1ad06df90219ba18f5fd974c99a4ce33fc4d05a804131ff6441a5b896d99->enter($__internal_ae5b1ad06df90219ba18f5fd974c99a4ce33fc4d05a804131ff6441a5b896d99_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_text"));

        // line 9
        echo $this->env->getExtension('translator')->trans("resetting.email.message", array("%username%" => $this->getAttribute((isset($context["user"]) ? $context["user"] : $this->getContext($context, "user")), "username", array()), "%confirmationUrl%" => (isset($context["confirmationUrl"]) ? $context["confirmationUrl"] : $this->getContext($context, "confirmationUrl"))), "FOSUserBundle");
        echo "
";
        
        $__internal_ae5b1ad06df90219ba18f5fd974c99a4ce33fc4d05a804131ff6441a5b896d99->leave($__internal_ae5b1ad06df90219ba18f5fd974c99a4ce33fc4d05a804131ff6441a5b896d99_prof);

    }

    // line 12
    public function block_body_html($context, array $blocks = array())
    {
        $__internal_4ec14ffb93df68e73a0ddc29c0ef64add51c5d9c6d9a84dfa5b61ea119493273 = $this->env->getExtension("native_profiler");
        $__internal_4ec14ffb93df68e73a0ddc29c0ef64add51c5d9c6d9a84dfa5b61ea119493273->enter($__internal_4ec14ffb93df68e73a0ddc29c0ef64add51c5d9c6d9a84dfa5b61ea119493273_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_html"));

        
        $__internal_4ec14ffb93df68e73a0ddc29c0ef64add51c5d9c6d9a84dfa5b61ea119493273->leave($__internal_4ec14ffb93df68e73a0ddc29c0ef64add51c5d9c6d9a84dfa5b61ea119493273_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:email.txt.twig";
    }

    public function getDebugInfo()
    {
        return array (  66 => 12,  57 => 9,  51 => 7,  42 => 4,  36 => 2,  29 => 12,  27 => 7,  25 => 2,);
    }
}
/* {% trans_default_domain 'FOSUserBundle' %}*/
/* {% block subject %}*/
/* {% autoescape false %}*/
/* {{ 'resetting.email.subject'|trans({'%username%': user.username}) }}*/
/* {% endautoescape %}*/
/* {% endblock %}*/
/* {% block body_text %}*/
/* {% autoescape false %}*/
/* {{ 'resetting.email.message'|trans({'%username%': user.username, '%confirmationUrl%': confirmationUrl}) }}*/
/* {% endautoescape %}*/
/* {% endblock %}*/
/* {% block body_html %}{% endblock %}*/
/* */
