<?php

/* FOSUserBundle:ChangePassword:changePassword.html.twig */
class __TwigTemplate_05610ad5510ee9c657752f5f9e3de2968c5474d61490156707c998c427664c65 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:ChangePassword:changePassword.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dd20c03ad1b0051c3bc856c181f4064e62f9ab1763549c257e13bacf0c163bf2 = $this->env->getExtension("native_profiler");
        $__internal_dd20c03ad1b0051c3bc856c181f4064e62f9ab1763549c257e13bacf0c163bf2->enter($__internal_dd20c03ad1b0051c3bc856c181f4064e62f9ab1763549c257e13bacf0c163bf2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:ChangePassword:changePassword.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_dd20c03ad1b0051c3bc856c181f4064e62f9ab1763549c257e13bacf0c163bf2->leave($__internal_dd20c03ad1b0051c3bc856c181f4064e62f9ab1763549c257e13bacf0c163bf2_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_14942bbfd9a09b49f7a1b6cc5807eb75299f04e125d37b5d2abfbf7b8ad2a85b = $this->env->getExtension("native_profiler");
        $__internal_14942bbfd9a09b49f7a1b6cc5807eb75299f04e125d37b5d2abfbf7b8ad2a85b->enter($__internal_14942bbfd9a09b49f7a1b6cc5807eb75299f04e125d37b5d2abfbf7b8ad2a85b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:ChangePassword:changePassword_content.html.twig", "FOSUserBundle:ChangePassword:changePassword.html.twig", 4)->display($context);
        
        $__internal_14942bbfd9a09b49f7a1b6cc5807eb75299f04e125d37b5d2abfbf7b8ad2a85b->leave($__internal_14942bbfd9a09b49f7a1b6cc5807eb75299f04e125d37b5d2abfbf7b8ad2a85b_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:ChangePassword:changePassword.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:ChangePassword:changePassword_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
