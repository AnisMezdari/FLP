<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_e5ce9cbb75baf27c95787f2a0c4c9dcc3ba6ad4d737a499ed8dcdfdb9581c86f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_50013ca1162c209f97c9aa340561d5790861cbf3d12cfe63d3085bcf3ac89d56 = $this->env->getExtension("native_profiler");
        $__internal_50013ca1162c209f97c9aa340561d5790861cbf3d12cfe63d3085bcf3ac89d56->enter($__internal_50013ca1162c209f97c9aa340561d5790861cbf3d12cfe63d3085bcf3ac89d56_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_50013ca1162c209f97c9aa340561d5790861cbf3d12cfe63d3085bcf3ac89d56->leave($__internal_50013ca1162c209f97c9aa340561d5790861cbf3d12cfe63d3085bcf3ac89d56_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_rows') ?>*/
/* */
