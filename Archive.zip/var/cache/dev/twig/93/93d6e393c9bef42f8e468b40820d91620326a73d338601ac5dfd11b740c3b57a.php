<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_42b4f82ed0863a5d959bbc9145ae33b66781f3fe05633d8866899aac046fe690 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4066c4615f6723b2194947912ac065fc2d46a7c49e1b1bb2510ee15d8b612c23 = $this->env->getExtension("native_profiler");
        $__internal_4066c4615f6723b2194947912ac065fc2d46a7c49e1b1bb2510ee15d8b612c23->enter($__internal_4066c4615f6723b2194947912ac065fc2d46a7c49e1b1bb2510ee15d8b612c23_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_4066c4615f6723b2194947912ac065fc2d46a7c49e1b1bb2510ee15d8b612c23->leave($__internal_4066c4615f6723b2194947912ac065fc2d46a7c49e1b1bb2510ee15d8b612c23_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->start($form) ?>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* <?php echo $view['form']->end($form) ?>*/
/* */
