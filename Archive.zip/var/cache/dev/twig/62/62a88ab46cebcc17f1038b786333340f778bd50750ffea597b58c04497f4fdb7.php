<?php

/* AccueilPlatformBundle:Accueil:frontAccueil.html.twig */
class __TwigTemplate_a7acc1ccb733f9cbc37a2ee478d856052019ebee93d3b9b422dbd9f0499634f2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::baseFront.html.twig", "AccueilPlatformBundle:Accueil:frontAccueil.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::baseFront.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_973fe19fe59ce75ade9239fd1008fc7275f21225dfc658c5eb11aa76dd168992 = $this->env->getExtension("native_profiler");
        $__internal_973fe19fe59ce75ade9239fd1008fc7275f21225dfc658c5eb11aa76dd168992->enter($__internal_973fe19fe59ce75ade9239fd1008fc7275f21225dfc658c5eb11aa76dd168992_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AccueilPlatformBundle:Accueil:frontAccueil.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_973fe19fe59ce75ade9239fd1008fc7275f21225dfc658c5eb11aa76dd168992->leave($__internal_973fe19fe59ce75ade9239fd1008fc7275f21225dfc658c5eb11aa76dd168992_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_d63871c2c8b859d1ab089a8bd70b5ff056d18a2af20cf55b2fcb726cced6f64a = $this->env->getExtension("native_profiler");
        $__internal_d63871c2c8b859d1ab089a8bd70b5ff056d18a2af20cf55b2fcb726cced6f64a->enter($__internal_d63871c2c8b859d1ab089a8bd70b5ff056d18a2af20cf55b2fcb726cced6f64a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "\t<div class = \"conteneurImagesAccueilFront\">
\t\t";
        // line 5
        $context["i"] = 0;
        // line 6
        echo "\t\t\t<div class = \"conteneurPremierDemi\">
\t\t";
        // line 7
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["photos"]) ? $context["photos"] : $this->getContext($context, "photos")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["photo"]) {
            // line 8
            echo "\t\t\t";
            if (((isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")) == twig_round(($this->getAttribute($context["loop"], "length", array()) / 2)))) {
                // line 9
                echo "\t\t\t\t</div>
\t\t\t\t<div class = \"conteneurDeuxiemDemi\">
\t\t\t";
            }
            // line 12
            echo "\t\t\t<img class = \" imagesAccueilFront\" src = \"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["photo"], "urlImage", array()), "html", null, true);
            echo "\" alt = \"Photographie\" />
\t\t\t";
            // line 13
            $context["i"] = ((isset($context["i"]) ? $context["i"] : $this->getContext($context, "i")) + 1);
            // line 14
            echo "\t\t";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['photo'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 15
        echo "\t\t</div>
\t</div>
";
        
        $__internal_d63871c2c8b859d1ab089a8bd70b5ff056d18a2af20cf55b2fcb726cced6f64a->leave($__internal_d63871c2c8b859d1ab089a8bd70b5ff056d18a2af20cf55b2fcb726cced6f64a_prof);

    }

    public function getTemplateName()
    {
        return "AccueilPlatformBundle:Accueil:frontAccueil.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 15,  80 => 14,  78 => 13,  73 => 12,  68 => 9,  65 => 8,  48 => 7,  45 => 6,  43 => 5,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "::baseFront.html.twig" %}*/
/* */
/* {% block body %}*/
/* 	<div class = "conteneurImagesAccueilFront">*/
/* 		{% set i = 0 %}*/
/* 			<div class = "conteneurPremierDemi">*/
/* 		{% for photo in photos %}*/
/* 			{% if i == (loop.length/2)|round %}*/
/* 				</div>*/
/* 				<div class = "conteneurDeuxiemDemi">*/
/* 			{% endif %}*/
/* 			<img class = " imagesAccueilFront" src = "{{photo.urlImage}}" alt = "Photographie" />*/
/* 			{% set i = i+1 %}*/
/* 		{% endfor %}*/
/* 		</div>*/
/* 	</div>*/
/* {% endblock %}*/
