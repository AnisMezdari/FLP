<?php

/* FOSUserBundle:Resetting:reset.html.twig */
class __TwigTemplate_eb87e03640112df1c1be15f8a2863e141b5f4d50999e091e0c3bcaf3c4716673 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Resetting:reset.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6e98add3051ae6be071bcf5f2f52d77cd1bdc615912c73d2b3eeb462bcb1ace5 = $this->env->getExtension("native_profiler");
        $__internal_6e98add3051ae6be071bcf5f2f52d77cd1bdc615912c73d2b3eeb462bcb1ace5->enter($__internal_6e98add3051ae6be071bcf5f2f52d77cd1bdc615912c73d2b3eeb462bcb1ace5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Resetting:reset.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6e98add3051ae6be071bcf5f2f52d77cd1bdc615912c73d2b3eeb462bcb1ace5->leave($__internal_6e98add3051ae6be071bcf5f2f52d77cd1bdc615912c73d2b3eeb462bcb1ace5_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_f1b9e567670c48b31224a3c6fa983bfa7b09fec017ecd57f9376b9bfe3bdcf51 = $this->env->getExtension("native_profiler");
        $__internal_f1b9e567670c48b31224a3c6fa983bfa7b09fec017ecd57f9376b9bfe3bdcf51->enter($__internal_f1b9e567670c48b31224a3c6fa983bfa7b09fec017ecd57f9376b9bfe3bdcf51_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Resetting:reset_content.html.twig", "FOSUserBundle:Resetting:reset.html.twig", 4)->display($context);
        
        $__internal_f1b9e567670c48b31224a3c6fa983bfa7b09fec017ecd57f9376b9bfe3bdcf51->leave($__internal_f1b9e567670c48b31224a3c6fa983bfa7b09fec017ecd57f9376b9bfe3bdcf51_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Resetting:reset.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Resetting:reset_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
