<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_f2bf1e2aeaa6cb662e3f28158de7898683a2f55a5a25ff1944326df9ff91637b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dab4011ac6d4d5760a6f46513559b455af0e977592950f6ce2f21a336d461714 = $this->env->getExtension("native_profiler");
        $__internal_dab4011ac6d4d5760a6f46513559b455af0e977592950f6ce2f21a336d461714->enter($__internal_dab4011ac6d4d5760a6f46513559b455af0e977592950f6ce2f21a336d461714_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_dab4011ac6d4d5760a6f46513559b455af0e977592950f6ce2f21a336d461714->leave($__internal_dab4011ac6d4d5760a6f46513559b455af0e977592950f6ce2f21a336d461714_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr>*/
/*     <td></td>*/
/*     <td>*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
