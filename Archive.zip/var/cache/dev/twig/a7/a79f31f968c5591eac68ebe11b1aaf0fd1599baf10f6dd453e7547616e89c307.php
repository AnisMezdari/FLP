<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_8c7122f527c531917edf41268b402dbe5d76153317a86dc74c0e63aa9ed293c9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_003194e7bcced2e1e172528744b3c57e9d9b3e6bf1c7398580bbedc656f46941 = $this->env->getExtension("native_profiler");
        $__internal_003194e7bcced2e1e172528744b3c57e9d9b3e6bf1c7398580bbedc656f46941->enter($__internal_003194e7bcced2e1e172528744b3c57e9d9b3e6bf1c7398580bbedc656f46941_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_003194e7bcced2e1e172528744b3c57e9d9b3e6bf1c7398580bbedc656f46941->leave($__internal_003194e7bcced2e1e172528744b3c57e9d9b3e6bf1c7398580bbedc656f46941_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'number')) ?>*/
/* */
