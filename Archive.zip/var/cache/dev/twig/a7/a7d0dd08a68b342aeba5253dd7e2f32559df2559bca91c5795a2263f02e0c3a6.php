<?php

/* PresentationPlatformBundle:Presentation:index.html.twig */
class __TwigTemplate_7adb728730ee5aaa7c1082ad9f3db6957564eb83489d0fa6dd3a1657f1da6dc0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("::base.html.twig", "PresentationPlatformBundle:Presentation:index.html.twig", 2);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_094cab5a15a1703fa45f0d9c00cf076f79ec25ff603c4d9e11f2491706b88905 = $this->env->getExtension("native_profiler");
        $__internal_094cab5a15a1703fa45f0d9c00cf076f79ec25ff603c4d9e11f2491706b88905->enter($__internal_094cab5a15a1703fa45f0d9c00cf076f79ec25ff603c4d9e11f2491706b88905_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PresentationPlatformBundle:Presentation:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_094cab5a15a1703fa45f0d9c00cf076f79ec25ff603c4d9e11f2491706b88905->leave($__internal_094cab5a15a1703fa45f0d9c00cf076f79ec25ff603c4d9e11f2491706b88905_prof);

    }

    // line 4
    public function block_body($context, array $blocks = array())
    {
        $__internal_2cebae54498e7886ac7e4bab064551745c03f1d652428253b391f222813f1b3d = $this->env->getExtension("native_profiler");
        $__internal_2cebae54498e7886ac7e4bab064551745c03f1d652428253b391f222813f1b3d->enter($__internal_2cebae54498e7886ac7e4bab064551745c03f1d652428253b391f222813f1b3d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 5
        echo "\t
\t<form  method = \"POST\" action= \"";
        // line 6
        echo $this->env->getExtension('routing')->getPath("presentation_platform_modification");
        echo "\" class = \"conteneurPresentation\" enctype=\"multipart/form-data\">
\t\t<h1>Présentation</h1>
\t\t<div class = \"conteneurBoutonPresentation\">
\t\t\t<input type=\"submit\" name=\"bouton\" value=\"Modifier\" class=\"boutonPresentation\"/>
\t\t</div>
\t\t<div class = \"conteneurTitrePresentation\">
\t\t\t<h1> <input class = \"titrePresentation form-control\" type=\"text\" value = \"";
        // line 12
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["presentation"]) ? $context["presentation"] : $this->getContext($context, "presentation")), "titre", array()), "html", null, true);
        echo "\" name=\"titre\" size=\"45\" /> </h1>
\t\t</div>

\t\t<div class = \"conteneurImagePresentationAndTextePresentation\">
\t\t\t<div class = \"conteneurImagePresentation\">
\t\t\t\t";
        // line 18
        echo "\t\t\t\t<img src = \"";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["presentation"]) ? $context["presentation"] : $this->getContext($context, "presentation")), "urlImage", array()), "html", null, true);
        echo "\" alt = \"Image de présentation\"  class = \"imagePresentation\"/>
\t\t\t\t
\t\t\t\t<input type = \"file\" name = \"image\" class = \"fileImagePresentation\" />
\t\t\t</div>

\t\t\t<div  class = \"conteneurTextePresentation\">
\t\t\t\t<div class=\"form-group\">
\t\t    \t\t<textarea class =\"form-control\" name = \"texte\" id=\"exampleTextarea\" >
\t\t\t\t\t\t";
        // line 26
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["presentation"]) ? $context["presentation"] : $this->getContext($context, "presentation")), "texte", array()), "html", null, true);
        echo "
\t\t\t\t\t</textarea>
\t\t \t\t</div>
\t\t\t</div>

\t\t</div>
\t</form>


";
        
        $__internal_2cebae54498e7886ac7e4bab064551745c03f1d652428253b391f222813f1b3d->leave($__internal_2cebae54498e7886ac7e4bab064551745c03f1d652428253b391f222813f1b3d_prof);

    }

    public function getTemplateName()
    {
        return "PresentationPlatformBundle:Presentation:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 26,  60 => 18,  52 => 12,  43 => 6,  40 => 5,  34 => 4,  11 => 2,);
    }
}
/* */
/* {% extends "::base.html.twig" %}*/
/* */
/* {% block body %}*/
/* 	*/
/* 	<form  method = "POST" action= "{{path('presentation_platform_modification')}}" class = "conteneurPresentation" enctype="multipart/form-data">*/
/* 		<h1>Présentation</h1>*/
/* 		<div class = "conteneurBoutonPresentation">*/
/* 			<input type="submit" name="bouton" value="Modifier" class="boutonPresentation"/>*/
/* 		</div>*/
/* 		<div class = "conteneurTitrePresentation">*/
/* 			<h1> <input class = "titrePresentation form-control" type="text" value = "{{presentation.titre}}" name="titre" size="45" /> </h1>*/
/* 		</div>*/
/* */
/* 		<div class = "conteneurImagePresentationAndTextePresentation">*/
/* 			<div class = "conteneurImagePresentation">*/
/* 				{# <img src = "{{asset('bundles/images/imen.jpg')}}" alt = "Image de présentation" /> #}*/
/* 				<img src = "{{ presentation.urlImage }}" alt = "Image de présentation"  class = "imagePresentation"/>*/
/* 				*/
/* 				<input type = "file" name = "image" class = "fileImagePresentation" />*/
/* 			</div>*/
/* */
/* 			<div  class = "conteneurTextePresentation">*/
/* 				<div class="form-group">*/
/* 		    		<textarea class ="form-control" name = "texte" id="exampleTextarea" >*/
/* 						{{presentation.texte}}*/
/* 					</textarea>*/
/* 		 		</div>*/
/* 			</div>*/
/* */
/* 		</div>*/
/* 	</form>*/
/* */
/* */
/* {% endblock %}*/
