<?php

/* PortfolioPlatformBundle:Portfolio:modificationCategorie.html.twig */
class __TwigTemplate_7919af4dec91bcaba931b92c2191b354e4308a93be249a858b95578ff7c01b6e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "PortfolioPlatformBundle:Portfolio:modificationCategorie.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b61135eb9d4b83629babff24e85b16ecbbd0a1d6d032e1ecbb340ef17b3d7f5b = $this->env->getExtension("native_profiler");
        $__internal_b61135eb9d4b83629babff24e85b16ecbbd0a1d6d032e1ecbb340ef17b3d7f5b->enter($__internal_b61135eb9d4b83629babff24e85b16ecbbd0a1d6d032e1ecbb340ef17b3d7f5b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PortfolioPlatformBundle:Portfolio:modificationCategorie.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b61135eb9d4b83629babff24e85b16ecbbd0a1d6d032e1ecbb340ef17b3d7f5b->leave($__internal_b61135eb9d4b83629babff24e85b16ecbbd0a1d6d032e1ecbb340ef17b3d7f5b_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_0d169ec9679b3729e5b0ebf67e81235dfc02bf15e2406d8f59465df4eb87933b = $this->env->getExtension("native_profiler");
        $__internal_0d169ec9679b3729e5b0ebf67e81235dfc02bf15e2406d8f59465df4eb87933b->enter($__internal_0d169ec9679b3729e5b0ebf67e81235dfc02bf15e2406d8f59465df4eb87933b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "

\t<div class = \"conteneurPorfolioModification\">
\t\t<h1 class = \"titrePortfolioModification\"> Portfolio / Catégorie </h1>

\t\t<form action = \"";
        // line 9
        echo $this->env->getExtension('routing')->getPath("portfolio_platform_modificationCategorie");
        echo "\" method = \"post\" class = \"conteneurFormulairePortfolioModif\">
\t\t\t<div class = \"conteneurInputPortfolioModif\">
\t\t\t\t<input type = \"submit\" name = \"boutonMoficationCategorie\" value = \"Modifier\"  />
\t\t\t</div>
\t\t\t";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) ? $context["categories"] : $this->getContext($context, "categories")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["categorie"]) {
            // line 14
            echo "\t\t\t\t<div class = \"conteneurInputPortfolioModif\">
\t\t\t\t\t<input type = \"text\" name = \"categorie";
            // line 15
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "\" value = \"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["categorie"], "valeur", array()), "html", null, true);
            echo "\" class = \"form-control inputPortfolioModif\"/>
\t\t\t\t\t<input type = \"hidden\" name= \"idCategorie";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "index", array()), "html", null, true);
            echo "\" value = \"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["categorie"], "id", array()), "html", null, true);
            echo "\"/>
\t\t\t\t</div>
\t\t\t\t<input type = \"hidden\" name = \"nombreCategorie\" value = \"";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($context["loop"], "length", array()), "html", null, true);
            echo "\"  />
\t\t\t";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['categorie'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 20
        echo "\t\t</form>

\t\t<div>
\t\t\t<button class = \"btn btn-primary\" id = \"boutonAjouterCategoriePortfolio\"> 
\t\t\t\tAjouter
\t\t\t</button>
\t\t</div>
\t</div>
";
        
        $__internal_0d169ec9679b3729e5b0ebf67e81235dfc02bf15e2406d8f59465df4eb87933b->leave($__internal_0d169ec9679b3729e5b0ebf67e81235dfc02bf15e2406d8f59465df4eb87933b_prof);

    }

    public function getTemplateName()
    {
        return "PortfolioPlatformBundle:Portfolio:modificationCategorie.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  103 => 20,  87 => 18,  80 => 16,  74 => 15,  71 => 14,  54 => 13,  47 => 9,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "::base.html.twig" %}*/
/* */
/* {% block body %}*/
/* */
/* */
/* 	<div class = "conteneurPorfolioModification">*/
/* 		<h1 class = "titrePortfolioModification"> Portfolio / Catégorie </h1>*/
/* */
/* 		<form action = "{{path('portfolio_platform_modificationCategorie')}}" method = "post" class = "conteneurFormulairePortfolioModif">*/
/* 			<div class = "conteneurInputPortfolioModif">*/
/* 				<input type = "submit" name = "boutonMoficationCategorie" value = "Modifier"  />*/
/* 			</div>*/
/* 			{% for categorie in categories %}*/
/* 				<div class = "conteneurInputPortfolioModif">*/
/* 					<input type = "text" name = "categorie{{loop.index}}" value = "{{categorie.valeur}}" class = "form-control inputPortfolioModif"/>*/
/* 					<input type = "hidden" name= "idCategorie{{loop.index}}" value = "{{categorie.id}}"/>*/
/* 				</div>*/
/* 				<input type = "hidden" name = "nombreCategorie" value = "{{loop.length}}"  />*/
/* 			{% endfor %}*/
/* 		</form>*/
/* */
/* 		<div>*/
/* 			<button class = "btn btn-primary" id = "boutonAjouterCategoriePortfolio"> */
/* 				Ajouter*/
/* 			</button>*/
/* 		</div>*/
/* 	</div>*/
/* {% endblock %}*/
