<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_9e3f26f696e198354d8ce318e54b5e324331adfc333c9be7ac5e4f584949a285 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_68ef5c70f1cc0d9c453acea7d18e8b69408f0c96c6b61f6d0ccaf0053e681c04 = $this->env->getExtension("native_profiler");
        $__internal_68ef5c70f1cc0d9c453acea7d18e8b69408f0c96c6b61f6d0ccaf0053e681c04->enter($__internal_68ef5c70f1cc0d9c453acea7d18e8b69408f0c96c6b61f6d0ccaf0053e681c04_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
        
        $__internal_68ef5c70f1cc0d9c453acea7d18e8b69408f0c96c6b61f6d0ccaf0053e681c04->leave($__internal_68ef5c70f1cc0d9c453acea7d18e8b69408f0c96c6b61f6d0ccaf0053e681c04_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/* */
