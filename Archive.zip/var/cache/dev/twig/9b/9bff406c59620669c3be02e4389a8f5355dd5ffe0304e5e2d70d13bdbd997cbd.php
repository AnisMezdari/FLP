<?php

/* @Framework/Form/form_end.html.php */
class __TwigTemplate_b84605b8da3a65db101ba3365a34c9524268d932d836986462320838bd0c4d17 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_81ae5606e9736e374203f124ceb9d31689ac559abc356b231aba93ae377eb12c = $this->env->getExtension("native_profiler");
        $__internal_81ae5606e9736e374203f124ceb9d31689ac559abc356b231aba93ae377eb12c->enter($__internal_81ae5606e9736e374203f124ceb9d31689ac559abc356b231aba93ae377eb12c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_end.html.php"));

        // line 1
        echo "<?php if (!isset(\$render_rest) || \$render_rest): ?>
<?php echo \$view['form']->rest(\$form) ?>
<?php endif ?>
</form>
";
        
        $__internal_81ae5606e9736e374203f124ceb9d31689ac559abc356b231aba93ae377eb12c->leave($__internal_81ae5606e9736e374203f124ceb9d31689ac559abc356b231aba93ae377eb12c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_end.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (!isset($render_rest) || $render_rest): ?>*/
/* <?php echo $view['form']->rest($form) ?>*/
/* <?php endif ?>*/
/* </form>*/
/* */
