<?php

/* FOSUserBundle:Group:show.html.twig */
class __TwigTemplate_e06cf8a79d7f081e8e6580f1bbed110fd5a1712f305fe0594dbda63051548875 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fea2f79fbdd055bff630cd2b6a0d07589c0daaffa50cf5f37856321ae5fcb3cd = $this->env->getExtension("native_profiler");
        $__internal_fea2f79fbdd055bff630cd2b6a0d07589c0daaffa50cf5f37856321ae5fcb3cd->enter($__internal_fea2f79fbdd055bff630cd2b6a0d07589c0daaffa50cf5f37856321ae5fcb3cd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fea2f79fbdd055bff630cd2b6a0d07589c0daaffa50cf5f37856321ae5fcb3cd->leave($__internal_fea2f79fbdd055bff630cd2b6a0d07589c0daaffa50cf5f37856321ae5fcb3cd_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_f59d62d52d1bc2e95b6801adbdf40351761e5e5077ce3d9a6f6949c6a3fa1722 = $this->env->getExtension("native_profiler");
        $__internal_f59d62d52d1bc2e95b6801adbdf40351761e5e5077ce3d9a6f6949c6a3fa1722->enter($__internal_f59d62d52d1bc2e95b6801adbdf40351761e5e5077ce3d9a6f6949c6a3fa1722_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:show_content.html.twig", "FOSUserBundle:Group:show.html.twig", 4)->display($context);
        
        $__internal_f59d62d52d1bc2e95b6801adbdf40351761e5e5077ce3d9a6f6949c6a3fa1722->leave($__internal_f59d62d52d1bc2e95b6801adbdf40351761e5e5077ce3d9a6f6949c6a3fa1722_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:show_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
