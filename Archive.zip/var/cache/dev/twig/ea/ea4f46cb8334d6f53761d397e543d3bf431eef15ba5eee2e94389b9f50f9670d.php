<?php

/* FOSUserBundle:Profile:edit.html.twig */
class __TwigTemplate_d7c5c71b8db885b0c289a16b867dbdf49dd6f89910b6d81d5ee499bc7aa5befc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Profile:edit.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_93333477978059d6914bfd873d10734013766a36e40a5e270ce1468aaf667867 = $this->env->getExtension("native_profiler");
        $__internal_93333477978059d6914bfd873d10734013766a36e40a5e270ce1468aaf667867->enter($__internal_93333477978059d6914bfd873d10734013766a36e40a5e270ce1468aaf667867_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_93333477978059d6914bfd873d10734013766a36e40a5e270ce1468aaf667867->leave($__internal_93333477978059d6914bfd873d10734013766a36e40a5e270ce1468aaf667867_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_4015e481a3999a12f3d3b3d4206470392c6c62640c3d20776d1f7a44f5f91e06 = $this->env->getExtension("native_profiler");
        $__internal_4015e481a3999a12f3d3b3d4206470392c6c62640c3d20776d1f7a44f5f91e06->enter($__internal_4015e481a3999a12f3d3b3d4206470392c6c62640c3d20776d1f7a44f5f91e06_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Profile:edit_content.html.twig", "FOSUserBundle:Profile:edit.html.twig", 4)->display($context);
        
        $__internal_4015e481a3999a12f3d3b3d4206470392c6c62640c3d20776d1f7a44f5f91e06->leave($__internal_4015e481a3999a12f3d3b3d4206470392c6c62640c3d20776d1f7a44f5f91e06_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Profile:edit_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
