<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_a9f115ceffa96cbf4572d07efc6275b4933b18b3ee803adda23e6c654489fb76 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_16eee0236b53ae1bfd8b6b620af6e8515e0f605ce289635405f881d550ff6a23 = $this->env->getExtension("native_profiler");
        $__internal_16eee0236b53ae1bfd8b6b620af6e8515e0f605ce289635405f881d550ff6a23->enter($__internal_16eee0236b53ae1bfd8b6b620af6e8515e0f605ce289635405f881d550ff6a23_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_16eee0236b53ae1bfd8b6b620af6e8515e0f605ce289635405f881d550ff6a23->leave($__internal_16eee0236b53ae1bfd8b6b620af6e8515e0f605ce289635405f881d550ff6a23_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'password')) ?>*/
/* */
