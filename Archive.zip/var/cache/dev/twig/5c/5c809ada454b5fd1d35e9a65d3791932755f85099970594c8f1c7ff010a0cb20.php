<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_5f9262d24b7c5142183ff9d75c6bf03e6b0e41c64e87189afcc6d7e388ad7a9f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_80808d0a34a0b1fa06af022acb29e5e5da53789b20cda52e77d8642163c16cc7 = $this->env->getExtension("native_profiler");
        $__internal_80808d0a34a0b1fa06af022acb29e5e5da53789b20cda52e77d8642163c16cc7->enter($__internal_80808d0a34a0b1fa06af022acb29e5e5da53789b20cda52e77d8642163c16cc7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_80808d0a34a0b1fa06af022acb29e5e5da53789b20cda52e77d8642163c16cc7->leave($__internal_80808d0a34a0b1fa06af022acb29e5e5da53789b20cda52e77d8642163c16cc7_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (count($errors) > 0): ?>*/
/*     <ul>*/
/*         <?php foreach ($errors as $error): ?>*/
/*             <li><?php echo $error->getMessage() ?></li>*/
/*         <?php endforeach; ?>*/
/*     </ul>*/
/* <?php endif ?>*/
/* */
