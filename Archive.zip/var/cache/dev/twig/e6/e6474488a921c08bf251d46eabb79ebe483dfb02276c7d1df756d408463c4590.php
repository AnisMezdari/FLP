<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_1694cf4fa5bfeb351e47c3231874a6cb1474f1b8769ae347473e6f4e5473909f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e8dc4bb8ba3848447dd687a39f2fd1db2969189b766d72e25a9da8dab214b473 = $this->env->getExtension("native_profiler");
        $__internal_e8dc4bb8ba3848447dd687a39f2fd1db2969189b766d72e25a9da8dab214b473->enter($__internal_e8dc4bb8ba3848447dd687a39f2fd1db2969189b766d72e25a9da8dab214b473_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_e8dc4bb8ba3848447dd687a39f2fd1db2969189b766d72e25a9da8dab214b473->leave($__internal_e8dc4bb8ba3848447dd687a39f2fd1db2969189b766d72e25a9da8dab214b473_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (isset($prototype)): ?>*/
/*     <?php $attr['data-prototype'] = $view->escape($view['form']->row($prototype)) ?>*/
/* <?php endif ?>*/
/* <?php echo $view['form']->widget($form, array('attr' => $attr)) ?>*/
/* */
