<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_324502971af42753a7ecfa73899bc62bb8ba61c1e96c4b6edb43d70ff5fbefff extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_79e6c6f0fd5bcdd7732938f85ec5062f8196ceb5e5812da4933ff4290618f626 = $this->env->getExtension("native_profiler");
        $__internal_79e6c6f0fd5bcdd7732938f85ec5062f8196ceb5e5812da4933ff4290618f626->enter($__internal_79e6c6f0fd5bcdd7732938f85ec5062f8196ceb5e5812da4933ff4290618f626_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_79e6c6f0fd5bcdd7732938f85ec5062f8196ceb5e5812da4933ff4290618f626->leave($__internal_79e6c6f0fd5bcdd7732938f85ec5062f8196ceb5e5812da4933ff4290618f626_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->label($form) ?>*/
/*     <?php echo $view['form']->errors($form) ?>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */
