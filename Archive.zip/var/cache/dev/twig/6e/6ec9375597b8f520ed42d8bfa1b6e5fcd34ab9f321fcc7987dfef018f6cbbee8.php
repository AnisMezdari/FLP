<?php

/* ::base.html.twig */
class __TwigTemplate_587adccec9efd690f2608b415e5eb968b4db1cf7912a5dc0f246492763090718 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'nav' => array($this, 'block_nav'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c766229d7017a638ba7b54705d7075bb8232da8f59e0d34552d1965e6f0db810 = $this->env->getExtension("native_profiler");
        $__internal_c766229d7017a638ba7b54705d7075bb8232da8f59e0d34552d1965e6f0db810->enter($__internal_c766229d7017a638ba7b54705d7075bb8232da8f59e0d34552d1965e6f0db810_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <meta name=\"viewport\" content=\"width-device-width, initial-scale-1.0\">

        <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>

        <link rel=\"stylesheet\" href=\"path/to/font-awesome/css/font-awesome.min.css\" />
        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("web/bundles/framework/images/logo_symfony.png"), "html", null, true);
        echo "\" />
        <link rel=\"stylesheet\" href=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css\" />

        <link rel=\"stylesheet\" href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/Accueil/css/accueil.css"), "html", null, true);
        echo "\" />
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/Presentation/css/presentationBO.css"), "html", null, true);
        echo "\" />
        <link rel=\"stylesheet\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/Contact/css/contactBO.css"), "html", null, true);
        echo "\" />
        <link rel=\"stylesheet\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/Portfolio/css/portfolioBo.css"), "html", null, true);
        echo "\" />
        <link rel=\"stylesheet\" href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/Portfolio/css/portfolioModifcationBO.css"), "html", null, true);
        echo "\" />
         <link rel=\"stylesheet\" href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/Tarif/css/tarif.css"), "html", null, true);
        echo "\" />

        <link href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css\" rel=\"stylesheet\">
        <link href=\"path/to/css/fileinput.min.css\" media=\"all\" rel=\"stylesheet\" type=\"text/css\" />
        <script src=\"//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js\"></script>
        <script type=\"text/javascript\" src=\"js/bootstrap-filestyle.min.js\"> </script> 
    

        ";
        // line 26
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 27
        echo "    </head>
    <body>
        <script src=\"//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\"></script>
        <script src=\"//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js\"></script>        
        ";
        // line 31
        $this->displayBlock('nav', $context, $blocks);
        // line 32
        echo "
        ";
        // line 33
        $this->displayBlock('body', $context, $blocks);
        // line 34
        echo "
        ";
        // line 35
        $this->displayBlock('javascripts', $context, $blocks);
        // line 36
        echo "
        <script type=\"text/javascript\" src=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/Base/js/nav.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 38
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/Accueil/js/accueil.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 39
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/Portfolio/js/portfolioModification.js"), "html", null, true);
        echo "\"></script>
        <script type=\"text/javascript\" src=\"";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/Portfolio/js/portfolio.js"), "html", null, true);
        echo "\"></script>

        <footer class = \"footer\">
             Copyright © 2017 Fleur de Lys Photography Tous droits Réservés, site créé par Anis Mezdari & Maroin Kassas.
        </footer>
    </body>
</html>
";
        
        $__internal_c766229d7017a638ba7b54705d7075bb8232da8f59e0d34552d1965e6f0db810->leave($__internal_c766229d7017a638ba7b54705d7075bb8232da8f59e0d34552d1965e6f0db810_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_25f7cf761feb4833ced8404f2b5d0ee174613ce7867ae517cb098dff1ed0466b = $this->env->getExtension("native_profiler");
        $__internal_25f7cf761feb4833ced8404f2b5d0ee174613ce7867ae517cb098dff1ed0466b->enter($__internal_25f7cf761feb4833ced8404f2b5d0ee174613ce7867ae517cb098dff1ed0466b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo " Fleur de Lys Photographie | ";
        
        $__internal_25f7cf761feb4833ced8404f2b5d0ee174613ce7867ae517cb098dff1ed0466b->leave($__internal_25f7cf761feb4833ced8404f2b5d0ee174613ce7867ae517cb098dff1ed0466b_prof);

    }

    // line 26
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_b345c3131ef46db902aafdb0ed8c152396083ee43deec9768948c5d002934d98 = $this->env->getExtension("native_profiler");
        $__internal_b345c3131ef46db902aafdb0ed8c152396083ee43deec9768948c5d002934d98->enter($__internal_b345c3131ef46db902aafdb0ed8c152396083ee43deec9768948c5d002934d98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_b345c3131ef46db902aafdb0ed8c152396083ee43deec9768948c5d002934d98->leave($__internal_b345c3131ef46db902aafdb0ed8c152396083ee43deec9768948c5d002934d98_prof);

    }

    // line 31
    public function block_nav($context, array $blocks = array())
    {
        $__internal_cf7be7cbbf3095ce679816e72ede94364cae5378f40961819b30ea9c0b61d67a = $this->env->getExtension("native_profiler");
        $__internal_cf7be7cbbf3095ce679816e72ede94364cae5378f40961819b30ea9c0b61d67a->enter($__internal_cf7be7cbbf3095ce679816e72ede94364cae5378f40961819b30ea9c0b61d67a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "nav"));

        echo " ";
        $this->loadTemplate("::nav.html.twig", "::base.html.twig", 31)->display($context);
        echo " ";
        
        $__internal_cf7be7cbbf3095ce679816e72ede94364cae5378f40961819b30ea9c0b61d67a->leave($__internal_cf7be7cbbf3095ce679816e72ede94364cae5378f40961819b30ea9c0b61d67a_prof);

    }

    // line 33
    public function block_body($context, array $blocks = array())
    {
        $__internal_afff28fa1cf2d85ee263d09c6d9be923e07f62a5b2082e40b91e710da2691e59 = $this->env->getExtension("native_profiler");
        $__internal_afff28fa1cf2d85ee263d09c6d9be923e07f62a5b2082e40b91e710da2691e59->enter($__internal_afff28fa1cf2d85ee263d09c6d9be923e07f62a5b2082e40b91e710da2691e59_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        echo "  ";
        
        $__internal_afff28fa1cf2d85ee263d09c6d9be923e07f62a5b2082e40b91e710da2691e59->leave($__internal_afff28fa1cf2d85ee263d09c6d9be923e07f62a5b2082e40b91e710da2691e59_prof);

    }

    // line 35
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_428149b1ff419f5239a65328b434209360b5238e94e437e6bec2efb584bf45b3 = $this->env->getExtension("native_profiler");
        $__internal_428149b1ff419f5239a65328b434209360b5238e94e437e6bec2efb584bf45b3->enter($__internal_428149b1ff419f5239a65328b434209360b5238e94e437e6bec2efb584bf45b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_428149b1ff419f5239a65328b434209360b5238e94e437e6bec2efb584bf45b3->leave($__internal_428149b1ff419f5239a65328b434209360b5238e94e437e6bec2efb584bf45b3_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  177 => 35,  165 => 33,  151 => 31,  140 => 26,  128 => 7,  113 => 40,  109 => 39,  105 => 38,  101 => 37,  98 => 36,  96 => 35,  93 => 34,  91 => 33,  88 => 32,  86 => 31,  80 => 27,  78 => 26,  67 => 18,  63 => 17,  59 => 16,  55 => 15,  51 => 14,  47 => 13,  41 => 10,  35 => 7,  27 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <meta name="viewport" content="width-device-width, initial-scale-1.0">*/
/* */
/*         <title>{% block title %} Fleur de Lys Photographie | {% endblock %}</title>*/
/* */
/*         <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css" />*/
/*         <link rel="icon" type="image/x-icon" href="{{ asset('web/bundles/framework/images/logo_symfony.png') }}" />*/
/*         <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" />*/
/* */
/*         <link rel="stylesheet" href="{{asset('bundles/Accueil/css/accueil.css')}}" />*/
/*         <link rel="stylesheet" href="{{asset('bundles/Presentation/css/presentationBO.css')}}" />*/
/*         <link rel="stylesheet" href="{{asset('bundles/Contact/css/contactBO.css')}}" />*/
/*         <link rel="stylesheet" href="{{asset('bundles/Portfolio/css/portfolioBo.css')}}" />*/
/*         <link rel="stylesheet" href="{{asset('bundles/Portfolio/css/portfolioModifcationBO.css')}}" />*/
/*          <link rel="stylesheet" href="{{asset('bundles/Tarif/css/tarif.css')}}" />*/
/* */
/*         <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">*/
/*         <link href="path/to/css/fileinput.min.css" media="all" rel="stylesheet" type="text/css" />*/
/*         <script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>*/
/*         <script type="text/javascript" src="js/bootstrap-filestyle.min.js"> </script> */
/*     */
/* */
/*         {% block stylesheets %}{% endblock %}*/
/*     </head>*/
/*     <body>*/
/*         <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>*/
/*         <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>        */
/*         {% block nav %} {% include '::nav.html.twig' %} {% endblock %}*/
/* */
/*         {% block body %}  {% endblock %}*/
/* */
/*         {% block javascripts %}{% endblock %}*/
/* */
/*         <script type="text/javascript" src="{{asset('bundles/Base/js/nav.js')}}"></script>*/
/*         <script type="text/javascript" src="{{asset('bundles/Accueil/js/accueil.js')}}"></script>*/
/*         <script type="text/javascript" src="{{asset('bundles/Portfolio/js/portfolioModification.js')}}"></script>*/
/*         <script type="text/javascript" src="{{asset('bundles/Portfolio/js/portfolio.js')}}"></script>*/
/* */
/*         <footer class = "footer">*/
/*              Copyright © 2017 Fleur de Lys Photography Tous droits Réservés, site créé par Anis Mezdari & Maroin Kassas.*/
/*         </footer>*/
/*     </body>*/
/* </html>*/
/* */
