<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_d5a7c7db0079f36cdaabae6117b4958ace2247faaa4154b0f440e84dddf497f3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_970a2e71e795c50c86660b652f312f8cd21b669cdb0707ec9e4ac3cf39e1e148 = $this->env->getExtension("native_profiler");
        $__internal_970a2e71e795c50c86660b652f312f8cd21b669cdb0707ec9e4ac3cf39e1e148->enter($__internal_970a2e71e795c50c86660b652f312f8cd21b669cdb0707ec9e4ac3cf39e1e148_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_970a2e71e795c50c86660b652f312f8cd21b669cdb0707ec9e4ac3cf39e1e148->leave($__internal_970a2e71e795c50c86660b652f312f8cd21b669cdb0707ec9e4ac3cf39e1e148_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_cb2479e6f992b12694dccc29ef72c0f6fbc25ed4fa2c1a0102d906e48500c98a = $this->env->getExtension("native_profiler");
        $__internal_cb2479e6f992b12694dccc29ef72c0f6fbc25ed4fa2c1a0102d906e48500c98a->enter($__internal_cb2479e6f992b12694dccc29ef72c0f6fbc25ed4fa2c1a0102d906e48500c98a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_cb2479e6f992b12694dccc29ef72c0f6fbc25ed4fa2c1a0102d906e48500c98a->leave($__internal_cb2479e6f992b12694dccc29ef72c0f6fbc25ed4fa2c1a0102d906e48500c98a_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_e75fb4c29f422461459f5ed76454a4743b243a8f8bb9f790025cbec824fd0d73 = $this->env->getExtension("native_profiler");
        $__internal_e75fb4c29f422461459f5ed76454a4743b243a8f8bb9f790025cbec824fd0d73->enter($__internal_e75fb4c29f422461459f5ed76454a4743b243a8f8bb9f790025cbec824fd0d73_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_e75fb4c29f422461459f5ed76454a4743b243a8f8bb9f790025cbec824fd0d73->leave($__internal_e75fb4c29f422461459f5ed76454a4743b243a8f8bb9f790025cbec824fd0d73_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_d7ccca2904ce3f38caf842ce36d5845115e9c6037a274caa68f266ffa85f7006 = $this->env->getExtension("native_profiler");
        $__internal_d7ccca2904ce3f38caf842ce36d5845115e9c6037a274caa68f266ffa85f7006->enter($__internal_d7ccca2904ce3f38caf842ce36d5845115e9c6037a274caa68f266ffa85f7006_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('routing')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_d7ccca2904ce3f38caf842ce36d5845115e9c6037a274caa68f266ffa85f7006->leave($__internal_d7ccca2904ce3f38caf842ce36d5845115e9c6037a274caa68f266ffa85f7006_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@WebProfiler/Profiler/layout.html.twig' %}*/
/* */
/* {% block toolbar %}{% endblock %}*/
/* */
/* {% block menu %}*/
/* <span class="label">*/
/*     <span class="icon">{{ include('@WebProfiler/Icon/router.svg') }}</span>*/
/*     <strong>Routing</strong>*/
/* </span>*/
/* {% endblock %}*/
/* */
/* {% block panel %}*/
/*     {{ render(path('_profiler_router', { token: token })) }}*/
/* {% endblock %}*/
/* */
