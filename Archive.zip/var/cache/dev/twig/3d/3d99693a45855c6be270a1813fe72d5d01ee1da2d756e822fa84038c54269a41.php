<?php

/* @Framework/Form/checkbox_widget.html.php */
class __TwigTemplate_ea0999926e51ad4f80ecd2dc89865f44f7dec2ed61725e7bc64ca2fe9de93953 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_89e70957a94357ced0a13887ad20f9233228d1113913921f6e40adf2d154cb90 = $this->env->getExtension("native_profiler");
        $__internal_89e70957a94357ced0a13887ad20f9233228d1113913921f6e40adf2d154cb90->enter($__internal_89e70957a94357ced0a13887ad20f9233228d1113913921f6e40adf2d154cb90_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        // line 1
        echo "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_89e70957a94357ced0a13887ad20f9233228d1113913921f6e40adf2d154cb90->leave($__internal_89e70957a94357ced0a13887ad20f9233228d1113913921f6e40adf2d154cb90_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/checkbox_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="checkbox"*/
/*     <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/*     <?php if (strlen($value) > 0): ?> value="<?php echo $view->escape($value) ?>"<?php endif ?>*/
/*     <?php if ($checked): ?> checked="checked"<?php endif ?>*/
/* />*/
/* */
