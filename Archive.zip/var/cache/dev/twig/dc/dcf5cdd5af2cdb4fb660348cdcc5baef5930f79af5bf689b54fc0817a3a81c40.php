<?php

/* FOSUserBundle:Profile:show.html.twig */
class __TwigTemplate_1c4cc863be89f3260c6ac5678a4e46b919099a9c3755eac7dd200f99c84e114f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Profile:show.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c5449809336ee9c73c597fe384a0d2ceebf1f6b0c8de33186c24de654f95efb8 = $this->env->getExtension("native_profiler");
        $__internal_c5449809336ee9c73c597fe384a0d2ceebf1f6b0c8de33186c24de654f95efb8->enter($__internal_c5449809336ee9c73c597fe384a0d2ceebf1f6b0c8de33186c24de654f95efb8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Profile:show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c5449809336ee9c73c597fe384a0d2ceebf1f6b0c8de33186c24de654f95efb8->leave($__internal_c5449809336ee9c73c597fe384a0d2ceebf1f6b0c8de33186c24de654f95efb8_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_ad69d001421907e4d7a27abf5b31b2c643120489e3f0c6aef28a6921828b8e63 = $this->env->getExtension("native_profiler");
        $__internal_ad69d001421907e4d7a27abf5b31b2c643120489e3f0c6aef28a6921828b8e63->enter($__internal_ad69d001421907e4d7a27abf5b31b2c643120489e3f0c6aef28a6921828b8e63_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Profile:show_content.html.twig", "FOSUserBundle:Profile:show.html.twig", 4)->display($context);
        
        $__internal_ad69d001421907e4d7a27abf5b31b2c643120489e3f0c6aef28a6921828b8e63->leave($__internal_ad69d001421907e4d7a27abf5b31b2c643120489e3f0c6aef28a6921828b8e63_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Profile:show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Profile:show_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
