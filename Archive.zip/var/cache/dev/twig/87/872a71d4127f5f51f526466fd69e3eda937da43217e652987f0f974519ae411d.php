<?php

/* @Framework/Form/number_widget.html.php */
class __TwigTemplate_25e12c1d03c38fcee30c987e5980eca81148f4a714d4424c3f43d75cd2edc110 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e2a472774b6d9fabf534ba36537ffd9f0415056d665970964d52d38f8e70e906 = $this->env->getExtension("native_profiler");
        $__internal_e2a472774b6d9fabf534ba36537ffd9f0415056d665970964d52d38f8e70e906->enter($__internal_e2a472774b6d9fabf534ba36537ffd9f0415056d665970964d52d38f8e70e906_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?>
";
        
        $__internal_e2a472774b6d9fabf534ba36537ffd9f0415056d665970964d52d38f8e70e906->leave($__internal_e2a472774b6d9fabf534ba36537ffd9f0415056d665970964d52d38f8e70e906_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/number_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'text')) ?>*/
/* */
