<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_3d1bd12bb877fcd8d29a93536094df1586061f03ca0c30c9314a5e7dcc5767e5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c63b107133c9bdf7a228c5db978146076f4233eb9cf877114558981a5fdbda07 = $this->env->getExtension("native_profiler");
        $__internal_c63b107133c9bdf7a228c5db978146076f4233eb9cf877114558981a5fdbda07->enter($__internal_c63b107133c9bdf7a228c5db978146076f4233eb9cf877114558981a5fdbda07_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_c63b107133c9bdf7a228c5db978146076f4233eb9cf877114558981a5fdbda07->leave($__internal_c63b107133c9bdf7a228c5db978146076f4233eb9cf877114558981a5fdbda07_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <textarea <?php echo $view['form']->block($form, 'widget_attributes') ?>><?php echo $view->escape($value) ?></textarea>*/
/* */
