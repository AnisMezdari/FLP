<?php

/* UserPlatformBundle:Default:index.html.twig */
class __TwigTemplate_c352abae4709cc076f412a11189aab93ee13398ec59b83e96f8ac6632174a7f1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e8f8337fd232a561fb1b4d37da0d7f8e75449dd52e4105564022bd22d2bb7887 = $this->env->getExtension("native_profiler");
        $__internal_e8f8337fd232a561fb1b4d37da0d7f8e75449dd52e4105564022bd22d2bb7887->enter($__internal_e8f8337fd232a561fb1b4d37da0d7f8e75449dd52e4105564022bd22d2bb7887_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "UserPlatformBundle:Default:index.html.twig"));

        // line 1
        echo "Hello World!
";
        
        $__internal_e8f8337fd232a561fb1b4d37da0d7f8e75449dd52e4105564022bd22d2bb7887->leave($__internal_e8f8337fd232a561fb1b4d37da0d7f8e75449dd52e4105564022bd22d2bb7887_prof);

    }

    public function getTemplateName()
    {
        return "UserPlatformBundle:Default:index.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* Hello World!*/
/* */
