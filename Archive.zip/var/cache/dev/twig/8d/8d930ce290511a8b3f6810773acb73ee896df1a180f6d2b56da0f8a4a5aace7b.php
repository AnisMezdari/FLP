<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_acd9d9246cfc52a7451a4da6065647b5f74747f0f6a0b4f8af055a08e28a5a16 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0361558b51992ff40e46db08a20364ec99cd267882f772e0ba42374762fc0db2 = $this->env->getExtension("native_profiler");
        $__internal_0361558b51992ff40e46db08a20364ec99cd267882f772e0ba42374762fc0db2->enter($__internal_0361558b51992ff40e46db08a20364ec99cd267882f772e0ba42374762fc0db2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_0361558b51992ff40e46db08a20364ec99cd267882f772e0ba42374762fc0db2->leave($__internal_0361558b51992ff40e46db08a20364ec99cd267882f772e0ba42374762fc0db2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'search')) ?>*/
/* */
