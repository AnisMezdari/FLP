<?php

/* ::navFront.html.twig */
class __TwigTemplate_1b856096d3a6e9b5b2e69a6d6491282a49fc12a119909e66faf4d4bac4290ebc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f20efc3bbbe5018389c2c325b4eee02ab80dae6092f241d40ca5204e769a7442 = $this->env->getExtension("native_profiler");
        $__internal_f20efc3bbbe5018389c2c325b4eee02ab80dae6092f241d40ca5204e769a7442->enter($__internal_f20efc3bbbe5018389c2c325b4eee02ab80dae6092f241d40ca5204e769a7442_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::navFront.html.twig"));

        // line 1
        echo "<header class = \"frontHeader\">
\t<img class = \"imgFrontHeader\" src = \"";
        // line 2
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("bundles/Accueil/image/logoFLS.gif"), "html", null, true);
        echo "\" alt = \"logoFlS\" />
\t<h4 class  = \"titreSite\"> Fleur de Lys Photograhy </h4>
</header>

<nav class = \"conteneurfrontNav\">
\t<div class = \"frontNav\">
\t\tAccueil
\t</div>
\t<div class = \"frontNav\">
\t\tPrésentation
\t</div>
\t<div class = \"frontNav\">
\t\tContact
\t</div>
\t<div class = \"frontNav\">
\t\tPortfolio
\t</div>
\t<div class = \"frontNav\">
\t\tTarif
\t</div>
\t<div class = \"frontNav\">
\t\tEvénement
\t</div>
\t<div class = \"frontNav\">
\t\tUtilisateurs
\t</div>
</nav>



";
        
        $__internal_f20efc3bbbe5018389c2c325b4eee02ab80dae6092f241d40ca5204e769a7442->leave($__internal_f20efc3bbbe5018389c2c325b4eee02ab80dae6092f241d40ca5204e769a7442_prof);

    }

    public function getTemplateName()
    {
        return "::navFront.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }
}
/* <header class = "frontHeader">*/
/* 	<img class = "imgFrontHeader" src = "{{asset('bundles/Accueil/image/logoFLS.gif')}}" alt = "logoFlS" />*/
/* 	<h4 class  = "titreSite"> Fleur de Lys Photograhy </h4>*/
/* </header>*/
/* */
/* <nav class = "conteneurfrontNav">*/
/* 	<div class = "frontNav">*/
/* 		Accueil*/
/* 	</div>*/
/* 	<div class = "frontNav">*/
/* 		Présentation*/
/* 	</div>*/
/* 	<div class = "frontNav">*/
/* 		Contact*/
/* 	</div>*/
/* 	<div class = "frontNav">*/
/* 		Portfolio*/
/* 	</div>*/
/* 	<div class = "frontNav">*/
/* 		Tarif*/
/* 	</div>*/
/* 	<div class = "frontNav">*/
/* 		Evénement*/
/* 	</div>*/
/* 	<div class = "frontNav">*/
/* 		Utilisateurs*/
/* 	</div>*/
/* </nav>*/
/* */
/* */
/* */
/* */
