<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_a5c90c9c8edbe7a9fe7a719ef0ba6b483ae25db9a003b95ae82098892d344395 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7e44a2a6c9c81dde2c03bd3a8891b9948cede753a377010938b11dc4954dc3f3 = $this->env->getExtension("native_profiler");
        $__internal_7e44a2a6c9c81dde2c03bd3a8891b9948cede753a377010938b11dc4954dc3f3->enter($__internal_7e44a2a6c9c81dde2c03bd3a8891b9948cede753a377010938b11dc4954dc3f3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_7e44a2a6c9c81dde2c03bd3a8891b9948cede753a377010938b11dc4954dc3f3->leave($__internal_7e44a2a6c9c81dde2c03bd3a8891b9948cede753a377010938b11dc4954dc3f3_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="<?php echo isset($type) ? $view->escape($type) : 'text' ?>" <?php echo $view['form']->block($form, 'widget_attributes') ?><?php if (!empty($value) || is_numeric($value)): ?> value="<?php echo $view->escape($value) ?>"<?php endif ?> />*/
/* */
