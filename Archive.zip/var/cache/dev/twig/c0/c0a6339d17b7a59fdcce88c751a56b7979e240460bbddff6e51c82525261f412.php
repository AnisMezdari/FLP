<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_cd53d334b1d1d39e907913dcb6d38cb971c579118348aa98edf99cf2810238c8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bac163a710923dacd1e9edd3f5c8e5d96c3d9eabba66b438dd3695bc16d92d9a = $this->env->getExtension("native_profiler");
        $__internal_bac163a710923dacd1e9edd3f5c8e5d96c3d9eabba66b438dd3695bc16d92d9a->enter($__internal_bac163a710923dacd1e9edd3f5c8e5d96c3d9eabba66b438dd3695bc16d92d9a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_bac163a710923dacd1e9edd3f5c8e5d96c3d9eabba66b438dd3695bc16d92d9a->leave($__internal_bac163a710923dacd1e9edd3f5c8e5d96c3d9eabba66b438dd3695bc16d92d9a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'widget_container_attributes') ?>*/
/* */
