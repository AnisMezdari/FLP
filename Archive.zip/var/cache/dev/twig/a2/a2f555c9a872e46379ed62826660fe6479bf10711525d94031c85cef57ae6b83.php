<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_e01191b5577bf969f2d9007bb96de620b43370e763a3eb7d83ade62cd878fc82 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_86bac09bb090f894291365db891e7b06c5362fc30fac3146f25458601730c0f3 = $this->env->getExtension("native_profiler");
        $__internal_86bac09bb090f894291365db891e7b06c5362fc30fac3146f25458601730c0f3->enter($__internal_86bac09bb090f894291365db891e7b06c5362fc30fac3146f25458601730c0f3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_86bac09bb090f894291365db891e7b06c5362fc30fac3146f25458601730c0f3->leave($__internal_86bac09bb090f894291365db891e7b06c5362fc30fac3146f25458601730c0f3_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'url')) ?>*/
/* */
