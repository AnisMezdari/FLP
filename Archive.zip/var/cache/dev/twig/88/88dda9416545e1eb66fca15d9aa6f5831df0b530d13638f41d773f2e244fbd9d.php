<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_67620d10da1670d5c5f1e2568613ae32b1ed9de6916ef83a20a8ebbe06d53763 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a18e3aa9d5685d859944ed4bf90a3be02fdb8b38c6c501aa054e614b4fbc4c9a = $this->env->getExtension("native_profiler");
        $__internal_a18e3aa9d5685d859944ed4bf90a3be02fdb8b38c6c501aa054e614b4fbc4c9a->enter($__internal_a18e3aa9d5685d859944ed4bf90a3be02fdb8b38c6c501aa054e614b4fbc4c9a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_a18e3aa9d5685d859944ed4bf90a3be02fdb8b38c6c501aa054e614b4fbc4c9a->leave($__internal_a18e3aa9d5685d859944ed4bf90a3be02fdb8b38c6c501aa054e614b4fbc4c9a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr>*/
/*     <td>*/
/*         <?php echo $view['form']->label($form) ?>*/
/*     </td>*/
/*     <td>*/
/*         <?php echo $view['form']->errors($form) ?>*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
