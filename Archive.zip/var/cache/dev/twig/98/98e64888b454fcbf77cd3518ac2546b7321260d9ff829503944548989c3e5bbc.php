<?php

/* @Framework/Form/range_widget.html.php */
class __TwigTemplate_4d0458ec86d5d69b0baa9ae7dfceae03047a95846baec433f25d11c7dfe36ae3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4af8e0d55a7d25937af90a1520a496f76a93c8d9fcc4edfef9baba5d386ebe0f = $this->env->getExtension("native_profiler");
        $__internal_4af8e0d55a7d25937af90a1520a496f76a93c8d9fcc4edfef9baba5d386ebe0f->enter($__internal_4af8e0d55a7d25937af90a1520a496f76a93c8d9fcc4edfef9baba5d386ebe0f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/range_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
";
        
        $__internal_4af8e0d55a7d25937af90a1520a496f76a93c8d9fcc4edfef9baba5d386ebe0f->leave($__internal_4af8e0d55a7d25937af90a1520a496f76a93c8d9fcc4edfef9baba5d386ebe0f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/range_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'range'));*/
/* */
