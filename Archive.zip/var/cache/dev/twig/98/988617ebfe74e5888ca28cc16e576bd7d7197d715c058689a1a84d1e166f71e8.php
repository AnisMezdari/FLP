<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_56516261d48f1837e08413cf8ff77a4ad11d150446c77a0f6486735bd39d2430 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f6e19dafde092bf04e5fb359ff285b5e8f703adf22e405f53134f71f38afe9f5 = $this->env->getExtension("native_profiler");
        $__internal_f6e19dafde092bf04e5fb359ff285b5e8f703adf22e405f53134f71f38afe9f5->enter($__internal_f6e19dafde092bf04e5fb359ff285b5e8f703adf22e405f53134f71f38afe9f5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_f6e19dafde092bf04e5fb359ff285b5e8f703adf22e405f53134f71f38afe9f5->leave($__internal_f6e19dafde092bf04e5fb359ff285b5e8f703adf22e405f53134f71f38afe9f5_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}
