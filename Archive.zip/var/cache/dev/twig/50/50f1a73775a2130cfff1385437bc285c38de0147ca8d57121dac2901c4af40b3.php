<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_991e1df8bbae3e4c0e5f554237f7eddfd305d308396a2aa73046c1945b5cf4c8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d7aa44ee7a0bf4e7ee82a88524545dc90e888a2792d6edab2cbdf3dd69172285 = $this->env->getExtension("native_profiler");
        $__internal_d7aa44ee7a0bf4e7ee82a88524545dc90e888a2792d6edab2cbdf3dd69172285->enter($__internal_d7aa44ee7a0bf4e7ee82a88524545dc90e888a2792d6edab2cbdf3dd69172285_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_d7aa44ee7a0bf4e7ee82a88524545dc90e888a2792d6edab2cbdf3dd69172285->leave($__internal_d7aa44ee7a0bf4e7ee82a88524545dc90e888a2792d6edab2cbdf3dd69172285_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($compound): ?>*/
/* <?php echo $view['form']->block($form, 'form_widget_compound')?>*/
/* <?php else: ?>*/
/* <?php echo $view['form']->block($form, 'form_widget_simple')?>*/
/* <?php endif ?>*/
/* */
