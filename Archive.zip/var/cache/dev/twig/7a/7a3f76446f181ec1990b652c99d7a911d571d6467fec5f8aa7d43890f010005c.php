<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_eee75a8e69237e348b3f227aa76f3018121a1e60d58865069f2d87178bdbe412 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c39c8e13c088bf96c4d57e739496c110c34a74ad603a96b7d140e430eb194851 = $this->env->getExtension("native_profiler");
        $__internal_c39c8e13c088bf96c4d57e739496c110c34a74ad603a96b7d140e430eb194851->enter($__internal_c39c8e13c088bf96c4d57e739496c110c34a74ad603a96b7d140e430eb194851_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_c39c8e13c088bf96c4d57e739496c110c34a74ad603a96b7d140e430eb194851->leave($__internal_c39c8e13c088bf96c4d57e739496c110c34a74ad603a96b7d140e430eb194851_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'reset')) ?>*/
/* */
