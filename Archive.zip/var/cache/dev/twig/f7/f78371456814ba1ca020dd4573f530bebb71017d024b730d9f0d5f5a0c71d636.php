<?php

/* @Framework/Form/form_rows.html.php */
class __TwigTemplate_a643c40616170fe26b4850c45d902ef643ac89a83a3f9b06a708e414c42989f6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a7b8f0ff46d636bad997ebe4370b506d621897d9b516424663aede5ba5a9b84e = $this->env->getExtension("native_profiler");
        $__internal_a7b8f0ff46d636bad997ebe4370b506d621897d9b516424663aede5ba5a9b84e->enter($__internal_a7b8f0ff46d636bad997ebe4370b506d621897d9b516424663aede5ba5a9b84e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rows.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child) : ?>
    <?php echo \$view['form']->row(\$child) ?>
<?php endforeach; ?>
";
        
        $__internal_a7b8f0ff46d636bad997ebe4370b506d621897d9b516424663aede5ba5a9b84e->leave($__internal_a7b8f0ff46d636bad997ebe4370b506d621897d9b516424663aede5ba5a9b84e_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rows.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php foreach ($form as $child) : ?>*/
/*     <?php echo $view['form']->row($child) ?>*/
/* <?php endforeach; ?>*/
/* */
