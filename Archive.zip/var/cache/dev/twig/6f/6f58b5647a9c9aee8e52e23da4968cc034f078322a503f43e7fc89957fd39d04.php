<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_d929aa20a24d5137883e2979d22687b404e03bb85825755723105e7088a658e3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f1c05d9a64c58e78aa41adb7de91d3d4bc944fdb0ed5b798619bb6790d85aba0 = $this->env->getExtension("native_profiler");
        $__internal_f1c05d9a64c58e78aa41adb7de91d3d4bc944fdb0ed5b798619bb6790d85aba0->enter($__internal_f1c05d9a64c58e78aa41adb7de91d3d4bc944fdb0ed5b798619bb6790d85aba0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_f1c05d9a64c58e78aa41adb7de91d3d4bc944fdb0ed5b798619bb6790d85aba0->leave($__internal_f1c05d9a64c58e78aa41adb7de91d3d4bc944fdb0ed5b798619bb6790d85aba0_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
