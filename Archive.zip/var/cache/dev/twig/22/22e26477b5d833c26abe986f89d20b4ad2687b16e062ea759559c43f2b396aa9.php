<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_bc3b8a004a70dbafe8324526f280c6956955937fc31375af55eb3b202ae8e9d9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8e931912c99a08f75dbbd23520300a8f24d68682ead9f0b686f80731634938fb = $this->env->getExtension("native_profiler");
        $__internal_8e931912c99a08f75dbbd23520300a8f24d68682ead9f0b686f80731634938fb->enter($__internal_8e931912c99a08f75dbbd23520300a8f24d68682ead9f0b686f80731634938fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_8e931912c99a08f75dbbd23520300a8f24d68682ead9f0b686f80731634938fb->leave($__internal_8e931912c99a08f75dbbd23520300a8f24d68682ead9f0b686f80731634938fb_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_c0e22bfb3e009149ff0c3c92e0042c509ddf32bff9c9bd0d21d48f9cf0f3d335 = $this->env->getExtension("native_profiler");
        $__internal_c0e22bfb3e009149ff0c3c92e0042c509ddf32bff9c9bd0d21d48f9cf0f3d335->enter($__internal_c0e22bfb3e009149ff0c3c92e0042c509ddf32bff9c9bd0d21d48f9cf0f3d335_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_c0e22bfb3e009149ff0c3c92e0042c509ddf32bff9c9bd0d21d48f9cf0f3d335->leave($__internal_c0e22bfb3e009149ff0c3c92e0042c509ddf32bff9c9bd0d21d48f9cf0f3d335_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */
