<?php

/* FOSUserBundle:Group:list.html.twig */
class __TwigTemplate_968de1bed4a198ead860a271fe372faf4f282bd57368ac90b3052ce0c1c109fe extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("FOSUserBundle::layout.html.twig", "FOSUserBundle:Group:list.html.twig", 1);
        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "FOSUserBundle::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2b3612d42360a2cb7a88b8419204c24393a3e3eb3f89d4c92e23f16bf6e80053 = $this->env->getExtension("native_profiler");
        $__internal_2b3612d42360a2cb7a88b8419204c24393a3e3eb3f89d4c92e23f16bf6e80053->enter($__internal_2b3612d42360a2cb7a88b8419204c24393a3e3eb3f89d4c92e23f16bf6e80053_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle:Group:list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2b3612d42360a2cb7a88b8419204c24393a3e3eb3f89d4c92e23f16bf6e80053->leave($__internal_2b3612d42360a2cb7a88b8419204c24393a3e3eb3f89d4c92e23f16bf6e80053_prof);

    }

    // line 3
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_68ffbe2bee6b4206d7af1a477754979d9f38e63613c1a9084d017380a0b51564 = $this->env->getExtension("native_profiler");
        $__internal_68ffbe2bee6b4206d7af1a477754979d9f38e63613c1a9084d017380a0b51564->enter($__internal_68ffbe2bee6b4206d7af1a477754979d9f38e63613c1a9084d017380a0b51564_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 4
        $this->loadTemplate("FOSUserBundle:Group:list_content.html.twig", "FOSUserBundle:Group:list.html.twig", 4)->display($context);
        
        $__internal_68ffbe2bee6b4206d7af1a477754979d9f38e63613c1a9084d017380a0b51564->leave($__internal_68ffbe2bee6b4206d7af1a477754979d9f38e63613c1a9084d017380a0b51564_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Group:list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "FOSUserBundle::layout.html.twig" %}*/
/* */
/* {% block fos_user_content %}*/
/* {% include "FOSUserBundle:Group:list_content.html.twig" %}*/
/* {% endblock fos_user_content %}*/
/* */
