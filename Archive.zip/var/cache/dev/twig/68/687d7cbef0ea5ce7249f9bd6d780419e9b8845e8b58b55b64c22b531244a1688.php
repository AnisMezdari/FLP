<?php

/* @Framework/Form/datetime_widget.html.php */
class __TwigTemplate_70334117f22b2b523e139692d5a123f220773a420c23420ca4c4c9d1a2f6aff8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cc875d4518f8f897bacc149c831b1d8240db05cfea6e6e7e813b0b4af983b128 = $this->env->getExtension("native_profiler");
        $__internal_cc875d4518f8f897bacc149c831b1d8240db05cfea6e6e7e813b0b4af983b128->enter($__internal_cc875d4518f8f897bacc149c831b1d8240db05cfea6e6e7e813b0b4af983b128_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/datetime_widget.html.php"));

        // line 1
        echo "<?php if (\$widget == 'single_text'): ?>
    <?php echo \$view['form']->block(\$form, 'form_widget_simple'); ?>
<?php else: ?>
    <div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
        <?php echo \$view['form']->widget(\$form['date']).' '.\$view['form']->widget(\$form['time']) ?>
    </div>
<?php endif ?>
";
        
        $__internal_cc875d4518f8f897bacc149c831b1d8240db05cfea6e6e7e813b0b4af983b128->leave($__internal_cc875d4518f8f897bacc149c831b1d8240db05cfea6e6e7e813b0b4af983b128_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/datetime_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($widget == 'single_text'): ?>*/
/*     <?php echo $view['form']->block($form, 'form_widget_simple'); ?>*/
/* <?php else: ?>*/
/*     <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/*         <?php echo $view['form']->widget($form['date']).' '.$view['form']->widget($form['time']) ?>*/
/*     </div>*/
/* <?php endif ?>*/
/* */
