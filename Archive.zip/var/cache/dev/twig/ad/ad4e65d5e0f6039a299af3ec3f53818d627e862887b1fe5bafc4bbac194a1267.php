<?php

/* @Framework/Form/button_widget.html.php */
class __TwigTemplate_2efb34dd5bbc7710109fc3d24ce9fec2ae49ff87af7f375c803c69ed582906ee extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_22b596d026d8f60cee13274c1e0eb5e806f6c88e165b94c7c4363de5fd4e74f3 = $this->env->getExtension("native_profiler");
        $__internal_22b596d026d8f60cee13274c1e0eb5e806f6c88e165b94c7c4363de5fd4e74f3->enter($__internal_22b596d026d8f60cee13274c1e0eb5e806f6c88e165b94c7c4363de5fd4e74f3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_widget.html.php"));

        // line 1
        echo "<?php if (!\$label) { \$label = isset(\$label_format)
    ? strtr(\$label_format, array('%name%' => \$name, '%id%' => \$id))
    : \$view['form']->humanize(\$name); } ?>
<button type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'button' ?>\" <?php echo \$view['form']->block(\$form, 'button_attributes') ?>><?php echo \$view->escape(false !== \$translation_domain ? \$view['translator']->trans(\$label, array(), \$translation_domain) : \$label) ?></button>
";
        
        $__internal_22b596d026d8f60cee13274c1e0eb5e806f6c88e165b94c7c4363de5fd4e74f3->leave($__internal_22b596d026d8f60cee13274c1e0eb5e806f6c88e165b94c7c4363de5fd4e74f3_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (!$label) { $label = isset($label_format)*/
/*     ? strtr($label_format, array('%name%' => $name, '%id%' => $id))*/
/*     : $view['form']->humanize($name); } ?>*/
/* <button type="<?php echo isset($type) ? $view->escape($type) : 'button' ?>" <?php echo $view['form']->block($form, 'button_attributes') ?>><?php echo $view->escape(false !== $translation_domain ? $view['translator']->trans($label, array(), $translation_domain) : $label) ?></button>*/
/* */
