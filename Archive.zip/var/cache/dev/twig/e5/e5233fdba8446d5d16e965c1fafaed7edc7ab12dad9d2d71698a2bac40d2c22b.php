<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_eeff70fce5c7c4ba0b1d689599115b33c9bfcea1371e0fc8da152870233e6bf5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ebb45b7296d79f042c97316a49d030ec71df97d3e8798c6ba9ae1a3baf6f671c = $this->env->getExtension("native_profiler");
        $__internal_ebb45b7296d79f042c97316a49d030ec71df97d3e8798c6ba9ae1a3baf6f671c->enter($__internal_ebb45b7296d79f042c97316a49d030ec71df97d3e8798c6ba9ae1a3baf6f671c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_ebb45b7296d79f042c97316a49d030ec71df97d3e8798c6ba9ae1a3baf6f671c->leave($__internal_ebb45b7296d79f042c97316a49d030ec71df97d3e8798c6ba9ae1a3baf6f671c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/* <?php foreach ($form as $child): ?>*/
/*     <?php echo $view['form']->widget($child) ?>*/
/*     <?php echo $view['form']->label($child, null, array('translation_domain' => $choice_translation_domain)) ?>*/
/* <?php endforeach ?>*/
/* </div>*/
/* */
