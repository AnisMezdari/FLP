<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_dd540aea0f6a5fb49fbe09e15f2dca4fc817d5fa78a97247a7ac9a83043b22a6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_341593b70ac5c04002f7d1b6f5acc006a90b904798db5a6fc78db3ba7ca98501 = $this->env->getExtension("native_profiler");
        $__internal_341593b70ac5c04002f7d1b6f5acc006a90b904798db5a6fc78db3ba7ca98501->enter($__internal_341593b70ac5c04002f7d1b6f5acc006a90b904798db5a6fc78db3ba7ca98501_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_341593b70ac5c04002f7d1b6f5acc006a90b904798db5a6fc78db3ba7ca98501->leave($__internal_341593b70ac5c04002f7d1b6f5acc006a90b904798db5a6fc78db3ba7ca98501_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'text')) ?> %*/
/* */
