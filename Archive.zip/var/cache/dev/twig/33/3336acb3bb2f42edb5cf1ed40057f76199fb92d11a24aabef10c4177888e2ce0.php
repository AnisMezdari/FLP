<?php

/* PortfolioPlatformBundle:Portfolio:index.html.twig */
class __TwigTemplate_246db659f086ae2e98e1568a8ce7d913442bfaa0d9516cdb3728a5e5f0099980 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "PortfolioPlatformBundle:Portfolio:index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0f1de10987fc623707bd57f52ed388f2bc238dce4eb52ac6b69d80fa237725b5 = $this->env->getExtension("native_profiler");
        $__internal_0f1de10987fc623707bd57f52ed388f2bc238dce4eb52ac6b69d80fa237725b5->enter($__internal_0f1de10987fc623707bd57f52ed388f2bc238dce4eb52ac6b69d80fa237725b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "PortfolioPlatformBundle:Portfolio:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0f1de10987fc623707bd57f52ed388f2bc238dce4eb52ac6b69d80fa237725b5->leave($__internal_0f1de10987fc623707bd57f52ed388f2bc238dce4eb52ac6b69d80fa237725b5_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_49fd2ac89f5445d9ba99b269cce361b77be0deba936a5ee2b7ec3fcdfe79ca57 = $this->env->getExtension("native_profiler");
        $__internal_49fd2ac89f5445d9ba99b269cce361b77be0deba936a5ee2b7ec3fcdfe79ca57->enter($__internal_49fd2ac89f5445d9ba99b269cce361b77be0deba936a5ee2b7ec3fcdfe79ca57_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
\t<div class = \"conteneurPorfolio\">
\t\t<h1 class = \"titrePortfolio\"> Portfolio </h1>

\t\t<div class = \"conteneurCategoriePortfolio\">
\t\t\t";
        // line 9
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["categories"]) ? $context["categories"] : $this->getContext($context, "categories")));
        foreach ($context['_seq'] as $context["_key"] => $context["categorie"]) {
            // line 10
            echo "\t\t\t\t<form action = \"";
            echo $this->env->getExtension('routing')->getPath("portfolio_platform_affichageImageParCategorie");
            echo "\" method = \"post\"  class =\" categoriePortfolio\">
\t\t\t\t\t<input type = \"submit\" class = \"btn btn-default\" value = \"";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute($context["categorie"], "valeur", array()), "html", null, true);
            echo "\" />
\t\t\t\t\t<input type = \"hidden\" value = \"";
            // line 12
            echo twig_escape_filter($this->env, $this->getAttribute($context["categorie"], "valeur", array()), "html", null, true);
            echo "\" name = \"lienCategoriePortfolio\" />
\t\t\t\t</form>
\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['categorie'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 15
        echo "\t\t\t<button class = \"btn btn-primary boutonCategoriePortfolio\" onclick=\"self.location.href='";
        echo $this->env->getExtension('routing')->getPath("portfolio_platform_modification");
        echo "'\" > 
\t\t\t\tModifier
\t\t\t</button> \t\t\t
\t\t</div>

\t\t<div class = \"conteneurImagesEtUploadPortfolio\">
\t\t\t<div class = \"conteneurUploadPorfolio\">
\t\t\t\t<input type = \"file\" class = \"uploadPorfolio\" multiple=\"\" name=\"filesToUpload[]\" id=\"filesToUploadPortfolio\" />
\t\t\t\t<input  type = \"submit\" value = \"Upload\"  class = \"boutonUploadPortfolio\" />
\t\t        <input type=\"hidden\" value=\"";
        // line 24
        echo $this->env->getExtension('routing')->getPath("portfolio_platform_ajoutImageParCategorie");
        echo "\" id =  \"lienAjoutPhoto\" />
\t\t        <input type=\"hidden\" id=\"lienSuppressionPhotoporfolio\" value=\"";
        // line 25
        echo $this->env->getExtension('routing')->getPath("portfolio_platform_suppressionImageParCategorie");
        echo "\" />
\t        \t<input type = \"hidden\" value = \"";
        // line 26
        echo twig_escape_filter($this->env, (isset($context["categorieSingle"]) ? $context["categorieSingle"] : $this->getContext($context, "categorieSingle")), "html", null, true);
        echo "\" id = \"idCategoriePorfolio\" />
\t\t\t</div>

\t\t\t<div class = \"conteneurImagesPortfolio\">
\t\t\t\t";
        // line 30
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["images"]) ? $context["images"] : $this->getContext($context, "images")));
        foreach ($context['_seq'] as $context["_key"] => $context["image"]) {
            echo " 
\t\t\t\t\t<div class = \"conteneurImagePortfolio\">
\t\t\t\t\t\t<img src = \"";
            // line 32
            echo twig_escape_filter($this->env, $this->getAttribute($context["image"], "urlImage", array()), "html", null, true);
            echo "\" alt = \"Photo\" class = \"imagePortfolio\" />
\t\t\t\t\t\t<span   class=\"glyphicon glyphicon-remove fa-lg croixSuppressionPortfolio\" > </span>
\t\t\t\t\t</div>
\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['image'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 36
        echo "\t\t\t</div>
\t\t</div>


\t</div>

";
        
        $__internal_49fd2ac89f5445d9ba99b269cce361b77be0deba936a5ee2b7ec3fcdfe79ca57->leave($__internal_49fd2ac89f5445d9ba99b269cce361b77be0deba936a5ee2b7ec3fcdfe79ca57_prof);

    }

    public function getTemplateName()
    {
        return "PortfolioPlatformBundle:Portfolio:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  114 => 36,  104 => 32,  97 => 30,  90 => 26,  86 => 25,  82 => 24,  69 => 15,  60 => 12,  56 => 11,  51 => 10,  47 => 9,  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "::base.html.twig" %}*/
/* */
/* {% block body %}*/
/* */
/* 	<div class = "conteneurPorfolio">*/
/* 		<h1 class = "titrePortfolio"> Portfolio </h1>*/
/* */
/* 		<div class = "conteneurCategoriePortfolio">*/
/* 			{% for categorie in categories %}*/
/* 				<form action = "{{path('portfolio_platform_affichageImageParCategorie')}}" method = "post"  class =" categoriePortfolio">*/
/* 					<input type = "submit" class = "btn btn-default" value = "{{categorie.valeur}}" />*/
/* 					<input type = "hidden" value = "{{categorie.valeur}}" name = "lienCategoriePortfolio" />*/
/* 				</form>*/
/* 			{% endfor %}*/
/* 			<button class = "btn btn-primary boutonCategoriePortfolio" onclick="self.location.href='{{path('portfolio_platform_modification')}}'" > */
/* 				Modifier*/
/* 			</button> 			*/
/* 		</div>*/
/* */
/* 		<div class = "conteneurImagesEtUploadPortfolio">*/
/* 			<div class = "conteneurUploadPorfolio">*/
/* 				<input type = "file" class = "uploadPorfolio" multiple="" name="filesToUpload[]" id="filesToUploadPortfolio" />*/
/* 				<input  type = "submit" value = "Upload"  class = "boutonUploadPortfolio" />*/
/* 		        <input type="hidden" value="{{ path('portfolio_platform_ajoutImageParCategorie') }}" id =  "lienAjoutPhoto" />*/
/* 		        <input type="hidden" id="lienSuppressionPhotoporfolio" value="{{ path('portfolio_platform_suppressionImageParCategorie') }}" />*/
/* 	        	<input type = "hidden" value = "{{categorieSingle}}" id = "idCategoriePorfolio" />*/
/* 			</div>*/
/* */
/* 			<div class = "conteneurImagesPortfolio">*/
/* 				{% for image in images %} */
/* 					<div class = "conteneurImagePortfolio">*/
/* 						<img src = "{{image.urlImage}}" alt = "Photo" class = "imagePortfolio" />*/
/* 						<span   class="glyphicon glyphicon-remove fa-lg croixSuppressionPortfolio" > </span>*/
/* 					</div>*/
/* 				{% endfor %}*/
/* 			</div>*/
/* 		</div>*/
/* */
/* */
/* 	</div>*/
/* */
/* {% endblock %}*/
/* */
