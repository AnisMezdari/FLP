<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_ea229f3541242caf94947a6bcbbe91ef12d3676c18a5d8f531ff3f8409f9c1aa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9460aff0dbbf339ec39debe9445bbbd8c7e630357ea53f79ebf7c0ce01d9f4fe = $this->env->getExtension("native_profiler");
        $__internal_9460aff0dbbf339ec39debe9445bbbd8c7e630357ea53f79ebf7c0ce01d9f4fe->enter($__internal_9460aff0dbbf339ec39debe9445bbbd8c7e630357ea53f79ebf7c0ce01d9f4fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_9460aff0dbbf339ec39debe9445bbbd8c7e630357ea53f79ebf7c0ce01d9f4fe->leave($__internal_9460aff0dbbf339ec39debe9445bbbd8c7e630357ea53f79ebf7c0ce01d9f4fe_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr style="display: none">*/
/*     <td colspan="2">*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
