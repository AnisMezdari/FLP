<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_a4cc01982b8b4b8d8004d03be7f61d57740aba3f8ade40d2c8f590eb7f44a04f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_44a4194f39650687c64bf3ee9f4bf96396634abab204fb97292c4f75fad91d72 = $this->env->getExtension("native_profiler");
        $__internal_44a4194f39650687c64bf3ee9f4bf96396634abab204fb97292c4f75fad91d72->enter($__internal_44a4194f39650687c64bf3ee9f4bf96396634abab204fb97292c4f75fad91d72_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_44a4194f39650687c64bf3ee9f4bf96396634abab204fb97292c4f75fad91d72->leave($__internal_44a4194f39650687c64bf3ee9f4bf96396634abab204fb97292c4f75fad91d72_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="radio"*/
/*     <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/*     value="<?php echo $view->escape($value) ?>"*/
/*     <?php if ($checked): ?> checked="checked"<?php endif ?>*/
/* />*/
/* */
