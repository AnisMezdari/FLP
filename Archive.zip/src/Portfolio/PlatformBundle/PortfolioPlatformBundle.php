<?php

namespace Portfolio\PlatformBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PortfolioPlatformBundle extends Bundle
{
}
