<?php

namespace Presentation\PlatformBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PresentationPlatformBundle extends Bundle
{
}
