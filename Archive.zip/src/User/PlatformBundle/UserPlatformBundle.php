<?php

namespace User\PlatformBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class UserPlatformBundle extends Bundle
{
}
