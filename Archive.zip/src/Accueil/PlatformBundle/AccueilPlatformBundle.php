<?php

namespace Accueil\PlatformBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AccueilPlatformBundle extends Bundle
{
}
