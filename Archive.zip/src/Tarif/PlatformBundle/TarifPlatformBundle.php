<?php

namespace Tarif\PlatformBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class TarifPlatformBundle extends Bundle
{
}
