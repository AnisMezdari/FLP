<?php

namespace Evenement\PlatformBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class EvenementPlatformBundle extends Bundle
{
}
