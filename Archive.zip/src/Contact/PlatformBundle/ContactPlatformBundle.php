<?php

namespace Contact\PlatformBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ContactPlatformBundle extends Bundle
{
}
